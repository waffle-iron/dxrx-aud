var require = meteorInstall({"lib":{"plugin":{"cordova-plugin-bactrack":{"www":{"bactrack.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// lib/plugin/cordova-plugin-bactrack/www/bactrack.js                                                                //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
bactrackName = "BACTrackPlugin";                                                                                     // 1
bactrack = {                                                                                                         // 2
	initWithDelegate: function initWithDelegate(successCallback, apiKey, timeoutSeconds) {                              // 3
		cordova.exec(successCallback, successCallback, window.bactrackName, "initWithDelegate", [apiKey, timeoutSeconds]);
	},                                                                                                                  // 5
                                                                                                                     //
	connectToNearestBreathalyzer: function connectToNearestBreathalyzer(successCallback, errorCallback) {               // 7
		cordova.exec(successCallback, errorCallback, window.bactrackName, "connectToNearestBreathalyzer", []);             // 8
	},                                                                                                                  // 9
                                                                                                                     //
	connectBreathalyzer: function connectBreathalyzer(preferredUuid, timeoutSeconds, successCallback, errorCallback) {  // 11
		cordova.exec(successCallback, errorCallback, window.bactrackName, "connectBreathalyzer", [preferredUuid, timeoutSeconds]);
	},                                                                                                                  // 13
                                                                                                                     //
	connectBreathalyzerAsync: function connectBreathalyzerAsync(preferredUuid, timeoutSeconds, successCallback, errorCallback) {
		cordova.exec(successCallback, errorCallback, window.bactrackName, "connectBreathalyzerAsync", [preferredUuid, timeoutSeconds]);
	},                                                                                                                  // 17
                                                                                                                     //
	startScan: function startScan(successCallback, errorCallback) {                                                     // 19
		cordova.exec(successCallback, errorCallback, window.bactrackName, "startScan", []);                                // 20
	},                                                                                                                  // 21
                                                                                                                     //
	stopScan: function stopScan(successCallback, errorCallback) {                                                       // 23
		cordova.exec(successCallback, errorCallback, window.bactrackName, "stopScan", []);                                 // 24
	},                                                                                                                  // 25
                                                                                                                     //
	disconnect: function disconnect(successCallback, errorCallback) {                                                   // 27
		cordova.exec(successCallback, errorCallback, window.bactrackName, "disconnect", []);                               // 28
	},                                                                                                                  // 29
                                                                                                                     //
	startCountdown: function startCountdown(successCallback, errorCallback) {                                           // 31
		cordova.exec(successCallback, errorCallback, window.bactrackName, "startCountdown", []);                           // 32
	},                                                                                                                  // 33
                                                                                                                     //
	getBreathalyzerBatteryLevel: function getBreathalyzerBatteryLevel(successCallback, errorCallback) {                 // 35
		cordova.exec(successCallback, errorCallback, window.bactrackName, "getBreathalyzerBatteryLevel", []);              // 36
	}                                                                                                                   // 37
};                                                                                                                   // 2
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},"imports":{"api":{"documents":{"server":{"publications.js":["meteor/meteor","../documents",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/documents/server/publications.js                                                                      //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Documents;module.import('../documents',{"Documents":function(v){Documents=v}});
                                                                                                                     // 2
                                                                                                                     //
Meteor.publish('documents', function () {                                                                            // 4
  return Documents.find();                                                                                           // 4
});                                                                                                                  // 4
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"documents.js":["faker","meteor/mongo","meteor/aldeed:simple-schema","meteor/dburles:factory",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/documents/documents.js                                                                                //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({Documents:function(){return Documents}});var faker;module.import('faker',{"default":function(v){faker=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var Factory;module.import('meteor/dburles:factory',{"Factory":function(v){Factory=v}});
                                                                                                                     // 2
                                                                                                                     // 3
                                                                                                                     // 4
                                                                                                                     //
var Documents = new Mongo.Collection('Documents');                                                                   // 6
                                                                                                                     //
Documents.schema = new SimpleSchema({                                                                                // 8
  title: {                                                                                                           // 9
    type: String,                                                                                                    // 10
    label: 'The title of the document.'                                                                              // 11
  }                                                                                                                  // 9
});                                                                                                                  // 8
                                                                                                                     //
Documents.attachSchema(Documents.schema);                                                                            // 15
                                                                                                                     //
Factory.define('document', Documents, {                                                                              // 17
  title: function title() {                                                                                          // 18
    return "lorem ipsum...";                                                                                         // 18
  }                                                                                                                  // 18
});                                                                                                                  // 17
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"methods.js":["./documents","meteor/aldeed:simple-schema","meteor/mdg:validated-method",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/documents/methods.js                                                                                  //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({insertDocument:function(){return insertDocument},updateDocument:function(){return updateDocument},removeDocument:function(){return removeDocument}});var Documents;module.import('./documents',{"Documents":function(v){Documents=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var ValidatedMethod;module.import('meteor/mdg:validated-method',{"ValidatedMethod":function(v){ValidatedMethod=v}});
                                                                                                                     // 2
                                                                                                                     // 3
                                                                                                                     //
var insertDocument = new ValidatedMethod({                                                                           // 5
  name: 'documents.insert',                                                                                          // 6
  validate: new SimpleSchema({                                                                                       // 7
    title: { type: String }                                                                                          // 8
  }).validator(),                                                                                                    // 7
  run: function run(document) {                                                                                      // 10
    Documents.insert(document);                                                                                      // 11
  }                                                                                                                  // 12
});                                                                                                                  // 5
                                                                                                                     //
var updateDocument = new ValidatedMethod({                                                                           // 15
  name: 'documents.update',                                                                                          // 16
  validate: new SimpleSchema({                                                                                       // 17
    _id: { type: String },                                                                                           // 18
    'update.title': { type: String, optional: true }                                                                 // 19
  }).validator(),                                                                                                    // 17
  run: function run(_ref) {                                                                                          // 21
    var _id = _ref._id;                                                                                              // 21
    var update = _ref.update;                                                                                        // 21
                                                                                                                     //
    Documents.update(_id, { $set: update });                                                                         // 22
  }                                                                                                                  // 23
});                                                                                                                  // 15
                                                                                                                     //
var removeDocument = new ValidatedMethod({                                                                           // 26
  name: 'documents.remove',                                                                                          // 27
  validate: new SimpleSchema({                                                                                       // 28
    _id: { type: String }                                                                                            // 29
  }).validator(),                                                                                                    // 28
  run: function run(_ref2) {                                                                                         // 31
    var _id = _ref2._id;                                                                                             // 31
                                                                                                                     //
    Documents.remove(_id);                                                                                           // 32
  }                                                                                                                  // 33
});                                                                                                                  // 26
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"posts":{"server":{"publications.js":["meteor/meteor","../posts",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/posts/server/publications.js                                                                          //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Posts;module.import('../posts',{"Posts":function(v){Posts=v}});
                                                                                                                     // 2
                                                                                                                     //
//Meteor.publish('posts', () => Posts.find());                                                                       //
                                                                                                                     //
Meteor.publish('posts', function () {                                                                                // 6
  return Posts.find();                                                                                               // 7
});                                                                                                                  // 8
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"methods.js":["/imports/api/posts/posts","/imports/api/topics/topics","meteor/aldeed:simple-schema","meteor/mdg:validated-method",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/posts/methods.js                                                                                      //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({insertPost:function(){return insertPost},updatePost:function(){return updatePost},removePost:function(){return removePost}});var Posts;module.import('/imports/api/posts/posts',{"Posts":function(v){Posts=v}});var Topics;module.import('/imports/api/topics/topics',{"Topics":function(v){Topics=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var ValidatedMethod;module.import('meteor/mdg:validated-method',{"ValidatedMethod":function(v){ValidatedMethod=v}});
                                                                                                                     // 2
                                                                                                                     // 3
                                                                                                                     // 4
                                                                                                                     //
var insertPost = new ValidatedMethod({                                                                               // 6
  name: 'posts.insert',                                                                                              // 7
  validate: new SimpleSchema({                                                                                       // 8
    title: { type: String },                                                                                         // 9
    createdAt: { type: Date },                                                                                       // 10
    'createdBy.display': { type: String, optional: true },                                                           // 11
    'createdBy.reference': { type: String, optional: true },                                                         // 12
    'createdBy.avatar': { type: String, optional: true },                                                            // 13
    topicId: { type: String, optional: true }                                                                        // 14
  }).validator(),                                                                                                    // 8
  run: function run(document) {                                                                                      // 16
    Posts.insert(document);                                                                                          // 17
    Topics.update({ _id: document.topicId }, {                                                                       // 18
      $inc: { replies: 1 },                                                                                          // 19
      $set: { activity: new Date() }                                                                                 // 20
    });                                                                                                              // 18
  }                                                                                                                  // 22
});                                                                                                                  // 6
                                                                                                                     //
var updatePost = new ValidatedMethod({                                                                               // 25
  name: 'posts.update',                                                                                              // 26
  validate: new SimpleSchema({                                                                                       // 27
    _id: { type: String },                                                                                           // 28
    'update.title': { type: String, optional: true }                                                                 // 29
  }).validator(),                                                                                                    // 27
  run: function run(_ref) {                                                                                          // 31
    var _id = _ref._id;                                                                                              // 31
    var update = _ref.update;                                                                                        // 31
                                                                                                                     //
    Posts.update(_id, { $set: update });                                                                             // 32
  }                                                                                                                  // 33
});                                                                                                                  // 25
                                                                                                                     //
var removePost = new ValidatedMethod({                                                                               // 36
  name: 'posts.remove',                                                                                              // 37
  validate: new SimpleSchema({                                                                                       // 38
    _id: { type: String }                                                                                            // 39
  }).validator(),                                                                                                    // 38
  run: function run(_ref2) {                                                                                         // 41
    var _id = _ref2._id;                                                                                             // 41
                                                                                                                     //
    //console.log("_id", _id);                                                                                       //
                                                                                                                     //
    Posts.remove(_id);                                                                                               // 44
    Topics.update({ _id: _id }, {                                                                                    // 45
      $inc: { replies: -1 },                                                                                         // 46
      $set: { activity: new Date() }                                                                                 // 47
    });                                                                                                              // 45
  }                                                                                                                  // 49
});                                                                                                                  // 36
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"posts.js":["faker","meteor/mongo","meteor/aldeed:simple-schema","meteor/dburles:factory",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/posts/posts.js                                                                                        //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({Posts:function(){return Posts}});var faker;module.import('faker',{"default":function(v){faker=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var Factory;module.import('meteor/dburles:factory',{"Factory":function(v){Factory=v}});
                                                                                                                     // 2
                                                                                                                     // 3
                                                                                                                     // 4
                                                                                                                     //
var Posts = new Mongo.Collection('Posts');                                                                           // 6
                                                                                                                     //
Posts.schema = new SimpleSchema({                                                                                    // 8
  title: {                                                                                                           // 9
    type: String,                                                                                                    // 10
    label: 'The title of the post.'                                                                                  // 11
  },                                                                                                                 // 9
  createdAt: {                                                                                                       // 13
    optional: true,                                                                                                  // 14
    type: Date,                                                                                                      // 15
    label: 'Date and time the post was created.'                                                                     // 16
  },                                                                                                                 // 13
  'createdBy.display': {                                                                                             // 18
    type: String,                                                                                                    // 19
    optional: true,                                                                                                  // 20
    label: 'Display name of the user who crated the post.'                                                           // 21
  },                                                                                                                 // 18
  'createdBy.reference': {                                                                                           // 23
    type: String,                                                                                                    // 24
    optional: true,                                                                                                  // 25
    label: 'User ID of the user who crated the pos'                                                                  // 26
  },                                                                                                                 // 23
  'createdBy.avatar': {                                                                                              // 28
    type: String,                                                                                                    // 29
    optional: true,                                                                                                  // 30
    label: 'Avatar of the user who crated the post.'                                                                 // 31
  },                                                                                                                 // 28
  topicId: {                                                                                                         // 33
    optional: true,                                                                                                  // 34
    type: String,                                                                                                    // 35
    label: 'Topic ID.'                                                                                               // 36
  }                                                                                                                  // 33
});                                                                                                                  // 8
                                                                                                                     //
Posts.attachSchema(Posts.schema);                                                                                    // 40
                                                                                                                     //
Factory.define('post', Posts, {                                                                                      // 42
  title: function title() {                                                                                          // 43
    return "lorem ipsum...";                                                                                         // 43
  },                                                                                                                 // 43
  createdAt: function createdAt() {                                                                                  // 44
    return new Date();                                                                                               // 44
  }                                                                                                                  // 44
});                                                                                                                  // 42
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"statistics":{"server":{"publications.js":["meteor/meteor","../statistics",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/statistics/server/publications.js                                                                     //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Statistics;module.import('../statistics',{"Statistics":function(v){Statistics=v}});
                                                                                                                     // 2
                                                                                                                     //
Meteor.publish('statistics', function () {                                                                           // 4
  return Statistics.find();                                                                                          // 4
});                                                                                                                  // 4
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"statistics.js":["meteor/mongo","meteor/aldeed:simple-schema",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/statistics/statistics.js                                                                              //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({Statistics:function(){return Statistics}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});
                                                                                                                     // 2
                                                                                                                     //
var Statistics = new Mongo.Collection('Statistics');                                                                 // 4
                                                                                                                     //
Statistics.schema = new SimpleSchema({                                                                               // 6
  date: {                                                                                                            // 7
    type: new Date(),                                                                                                // 8
    label: 'Date.'                                                                                                   // 9
  },                                                                                                                 // 7
  usersCount: {                                                                                                      // 11
    type: new Number(),                                                                                              // 12
    label: 'Users Count'                                                                                             // 13
  },                                                                                                                 // 11
  postsCount: {                                                                                                      // 15
    type: new Number(),                                                                                              // 16
    label: 'Posts Count'                                                                                             // 17
  },                                                                                                                 // 15
  topicsCount: {                                                                                                     // 19
    type: new Number(),                                                                                              // 20
    label: 'Topics Count'                                                                                            // 21
  },                                                                                                                 // 19
  patientsCount: {                                                                                                   // 23
    type: new Number(),                                                                                              // 24
    label: 'Patients Count'                                                                                          // 25
  },                                                                                                                 // 23
  practitionersCount: {                                                                                              // 27
    type: new Number(),                                                                                              // 28
    label: 'Practitioners Count'                                                                                     // 29
  }                                                                                                                  // 27
});                                                                                                                  // 6
                                                                                                                     //
Statistics.attachSchema(Statistics.schema);                                                                          // 33
                                                                                                                     //
// import faker from 'faker';                                                                                        //
// import { Factory } from 'meteor/dburles:factory';                                                                 //
// Factory.define('statistics', Statistics, {                                                                        //
//   title: () => "lorem ipsum...",                                                                                  //
// });                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"topics":{"server":{"publications.js":["/imports/api/topics/topics",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/topics/server/publications.js                                                                         //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var Topics;module.import('/imports/api/topics/topics',{"Topics":function(v){Topics=v}});                             // 1
                                                                                                                     //
Meteor.publish('topics', function () {                                                                               // 3
  return Topics.find();                                                                                              // 3
});                                                                                                                  // 3
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"methods.js":["meteor/aldeed:simple-schema","meteor/mdg:validated-method","/imports/api/topics/topics",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/topics/methods.js                                                                                     //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({insertTopic:function(){return insertTopic},updateTopic:function(){return updateTopic},removeTopic:function(){return removeTopic},removeTopicById:function(){return removeTopicById}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var ValidatedMethod;module.import('meteor/mdg:validated-method',{"ValidatedMethod":function(v){ValidatedMethod=v}});var Topics;module.import('/imports/api/topics/topics',{"Topics":function(v){Topics=v}});
                                                                                                                     // 2
                                                                                                                     //
                                                                                                                     // 4
                                                                                                                     //
var insertTopic = new ValidatedMethod({                                                                              // 7
  name: 'topics.insert',                                                                                             // 8
  // validate: function(){                                                                                           //
  //   return true;                                                                                                  //
  // },                                                                                                              //
  validate: new SimpleSchema({                                                                                       // 12
    'name': { type: String },                                                                                        // 13
    'createdAt': { type: Date },                                                                                     // 14
    'createdBy.display': { type: String, optional: true },                                                           // 15
    'createdBy.reference': { type: String, optional: true },                                                         // 16
    'createdBy.avatar': { type: String, optional: true },                                                            // 17
    'photo.$.url': { type: String, optional: true }                                                                  // 18
  }).validator(),                                                                                                    // 12
  run: function run(document) {                                                                                      // 20
    console.log("insertTopic");                                                                                      // 21
                                                                                                                     //
    document.replies = 0;                                                                                            // 23
    document.views = 0;                                                                                              // 24
    document.activity = new Date();                                                                                  // 25
                                                                                                                     //
    console.log("document", document);                                                                               // 27
                                                                                                                     //
    return Topics.insert(document);                                                                                  // 29
  }                                                                                                                  // 30
});                                                                                                                  // 7
                                                                                                                     //
var updateTopic = new ValidatedMethod({                                                                              // 33
  name: 'topics.update',                                                                                             // 34
  validate: new SimpleSchema({                                                                                       // 35
    '_id': { type: String },                                                                                         // 36
    'update.name': { type: String }                                                                                  // 37
  }).validator(),                                                                                                    // 35
  run: function run(_ref) {                                                                                          // 39
    var _id = _ref._id;                                                                                              // 39
    var update = _ref.update;                                                                                        // 39
                                                                                                                     //
    console.log("updateTopic");                                                                                      // 40
                                                                                                                     //
    var topic = Topics.findOne({ _id: _id });                                                                        // 42
                                                                                                                     //
    delete topic._id;                                                                                                // 44
    delete topic._document;                                                                                          // 45
    delete topic._super_;                                                                                            // 46
                                                                                                                     //
    topic.name = update.name;                                                                                        // 48
    topic.createdAt = update.createdAt;                                                                              // 49
    topic.category = update.category;                                                                                // 50
    topic.replies = update.replies;                                                                                  // 51
    topic.views = update.views;                                                                                      // 52
    topic.activity = update.activity;                                                                                // 53
    topic.photo = [];                                                                                                // 54
                                                                                                                     //
    // if (update.gender) {                                                                                          //
    //   topic.photo.push({                                                                                          //
    //     url: update.photo                                                                                         //
    //   });                                                                                                         //
    // }                                                                                                             //
                                                                                                                     //
    Topics.update({ _id: _id }, { $set: topic });                                                                    // 62
  }                                                                                                                  // 64
});                                                                                                                  // 33
var removeTopic = new ValidatedMethod({                                                                              // 66
  name: 'topics.remove',                                                                                             // 67
  validate: new SimpleSchema({                                                                                       // 68
    _id: { type: String }                                                                                            // 69
  }).validator(),                                                                                                    // 68
  run: function run(_ref2) {                                                                                         // 71
    var _id = _ref2._id;                                                                                             // 71
                                                                                                                     //
    console.log("Removing topic " + _id);                                                                            // 72
    Topics.remove(_id);                                                                                              // 73
  }                                                                                                                  // 74
});                                                                                                                  // 66
                                                                                                                     //
var removeTopicById = new ValidatedMethod({                                                                          // 78
  name: 'topics.removeById',                                                                                         // 79
  validate: new SimpleSchema({                                                                                       // 80
    '_id': { type: String }                                                                                          // 81
  }).validator(),                                                                                                    // 80
  run: function run(_ref3) {                                                                                         // 83
    var _id = _ref3._id;                                                                                             // 83
                                                                                                                     //
    console.log("Removing topic " + _id);                                                                            // 84
    Topics.remove({ _id: _id });                                                                                     // 85
  }                                                                                                                  // 86
});                                                                                                                  // 78
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"topics.js":["faker","meteor/mongo","meteor/aldeed:simple-schema","meteor/dburles:factory",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/topics/topics.js                                                                                      //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({Topics:function(){return Topics}});var faker;module.import('faker',{"default":function(v){faker=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var Factory;module.import('meteor/dburles:factory',{"Factory":function(v){Factory=v}});
                                                                                                                     // 2
                                                                                                                     // 3
                                                                                                                     // 4
                                                                                                                     //
var Topics = new Mongo.Collection('Topics');                                                                         // 6
                                                                                                                     //
Topics.schema = new SimpleSchema({                                                                                   // 8
  'name': {                                                                                                          // 9
    type: String,                                                                                                    // 10
    label: 'Forum topic'                                                                                             // 11
  },                                                                                                                 // 9
  'cateogry': {                                                                                                      // 13
    type: String,                                                                                                    // 14
    optional: true,                                                                                                  // 15
    label: 'Topic category'                                                                                          // 16
  },                                                                                                                 // 13
  'replies': {                                                                                                       // 18
    type: Number,                                                                                                    // 19
    optional: true,                                                                                                  // 20
    label: 'Number of replies'                                                                                       // 21
  },                                                                                                                 // 18
  'views': {                                                                                                         // 23
    type: Number,                                                                                                    // 24
    optional: true,                                                                                                  // 25
    label: 'Number of views'                                                                                         // 26
  },                                                                                                                 // 23
  'createdAt': {                                                                                                     // 28
    type: Date,                                                                                                      // 29
    optional: true,                                                                                                  // 30
    label: 'CreatedAt date'                                                                                          // 31
  },                                                                                                                 // 28
  'createdBy.display': {                                                                                             // 33
    type: String,                                                                                                    // 34
    optional: true,                                                                                                  // 35
    label: 'CreatedBy.display.'                                                                                      // 36
  },                                                                                                                 // 33
  'createdBy.reference': {                                                                                           // 38
    type: String,                                                                                                    // 39
    optional: true,                                                                                                  // 40
    label: 'CreatedBy.reference.'                                                                                    // 41
  },                                                                                                                 // 38
  'createdBy.avatar': {                                                                                              // 43
    type: String,                                                                                                    // 44
    optional: true,                                                                                                  // 45
    label: 'Avatar of the user who crated the post.'                                                                 // 46
  },                                                                                                                 // 43
  'activity': {                                                                                                      // 48
    type: Date,                                                                                                      // 49
    optional: true,                                                                                                  // 50
    label: 'Last activity.'                                                                                          // 51
  },                                                                                                                 // 48
  'photo.$.url': {                                                                                                   // 53
    type: String,                                                                                                    // 54
    optional: true,                                                                                                  // 55
    label: 'Users.'                                                                                                  // 56
  }                                                                                                                  // 53
});                                                                                                                  // 8
                                                                                                                     //
Topics.attachSchema(Topics.schema);                                                                                  // 60
                                                                                                                     //
Factory.define('topic', Topics, {                                                                                    // 62
  name: function name() {                                                                                            // 63
    return "lorem ipsum...";                                                                                         // 63
  },                                                                                                                 // 63
  createdAt: function createdAt() {                                                                                  // 64
    return new Date();                                                                                               // 64
  }                                                                                                                  // 64
});                                                                                                                  // 62
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"devices":{"devices.js":["faker","meteor/mongo","meteor/aldeed:simple-schema","meteor/dburles:factory",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/devices/devices.js                                                                                    //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({Devices:function(){return Devices}});var faker;module.import('faker',{"default":function(v){faker=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var Factory;module.import('meteor/dburles:factory',{"Factory":function(v){Factory=v}});
                                                                                                                     // 2
                                                                                                                     // 3
                                                                                                                     // 4
                                                                                                                     //
var Devices = new Mongo.Collection('Devices');                                                                       // 6
                                                                                                                     //
Devices.schema = new SimpleSchema({                                                                                  // 8
  deviceName: {                                                                                                      // 9
    type: String,                                                                                                    // 10
    label: 'The name of the device.'                                                                                 // 11
  },                                                                                                                 // 9
  deviceProductId: {                                                                                                 // 13
    type: String,                                                                                                    // 14
    label: 'The product id code of the device.'                                                                      // 15
  },                                                                                                                 // 13
  patientId: {                                                                                                       // 17
    type: String,                                                                                                    // 18
    label: 'Patient ID.'                                                                                             // 19
  },                                                                                                                 // 17
  createdAt: {                                                                                                       // 21
    type: Date,                                                                                                      // 22
    label: 'Date and time that this device was bound to this patient.'                                               // 23
  },                                                                                                                 // 21
  createdBy: {                                                                                                       // 25
    type: String,                                                                                                    // 26
    label: 'Creator of this record.'                                                                                 // 27
  }                                                                                                                  // 25
});                                                                                                                  // 8
                                                                                                                     //
Devices.attachSchema(Devices.schema);                                                                                // 31
                                                                                                                     //
Factory.define('device', Devices, {                                                                                  // 33
  title: function title() {                                                                                          // 34
    return "lorem ipsum...";                                                                                         // 34
  },                                                                                                                 // 34
  createdAt: function createdAt() {                                                                                  // 35
    return new Date();                                                                                               // 35
  }                                                                                                                  // 35
});                                                                                                                  // 33
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"methods.js":["/imports/api/devices/devices","meteor/aldeed:simple-schema","meteor/mdg:validated-method",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/devices/methods.js                                                                                    //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({insertDevice:function(){return insertDevice},updateDevice:function(){return updateDevice},removeDevice:function(){return removeDevice}});var Devices;module.import('/imports/api/devices/devices',{"Devices":function(v){Devices=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var ValidatedMethod;module.import('meteor/mdg:validated-method',{"ValidatedMethod":function(v){ValidatedMethod=v}});
                                                                                                                     // 2
                                                                                                                     // 3
                                                                                                                     //
var insertDevice = new ValidatedMethod({                                                                             // 5
  name: 'devices.insert',                                                                                            // 6
  validate: new SimpleSchema({                                                                                       // 7
    deviceName: { type: String },                                                                                    // 8
    deviceProductId: { type: String },                                                                               // 9
    createdAt: { type: Date },                                                                                       // 10
    patientId: { type: String }                                                                                      // 11
  }).validator(),                                                                                                    // 7
  run: function run(document) {                                                                                      // 13
    Devices.insert(document);                                                                                        // 14
  }                                                                                                                  // 15
});                                                                                                                  // 5
                                                                                                                     //
var updateDevice = new ValidatedMethod({                                                                             // 18
  name: 'devices.update',                                                                                            // 19
  validate: new SimpleSchema({                                                                                       // 20
    _id: { type: String },                                                                                           // 21
    'update.deviceName': { type: String, optional: true },                                                           // 22
    'update.deviceProductId': { type: String, optional: true }                                                       // 23
  }).validator(),                                                                                                    // 20
  run: function run(_ref) {                                                                                          // 25
    var _id = _ref._id;                                                                                              // 25
    var update = _ref.update;                                                                                        // 25
                                                                                                                     //
    Devices.update(_id, { $set: update });                                                                           // 26
  }                                                                                                                  // 27
});                                                                                                                  // 18
                                                                                                                     //
var removeDevice = new ValidatedMethod({                                                                             // 30
  name: 'devices.remove',                                                                                            // 31
  validate: new SimpleSchema({                                                                                       // 32
    _id: { type: String }                                                                                            // 33
  }).validator(),                                                                                                    // 32
  run: function run(_ref2) {                                                                                         // 35
    var _id = _ref2._id;                                                                                             // 35
                                                                                                                     //
    Devices.remove(_id);                                                                                             // 36
  }                                                                                                                  // 37
});                                                                                                                  // 30
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"observations":{"methods.js":["/imports/api/observations/observations","meteor/aldeed:simple-schema","meteor/mdg:validated-method",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/observations/methods.js                                                                               //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({insertObservation:function(){return insertObservation},updateObservation:function(){return updateObservation},removeObservation:function(){return removeObservation}});var Observations;module.import('/imports/api/observations/observations',{"Observations":function(v){Observations=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var ValidatedMethod;module.import('meteor/mdg:validated-method',{"ValidatedMethod":function(v){ValidatedMethod=v}});
                                                                                                                     // 2
                                                                                                                     // 3
                                                                                                                     //
var insertObservation = new ValidatedMethod({                                                                        // 5
  name: 'observations.insert',                                                                                       // 6
  validate: new SimpleSchema({                                                                                       // 7
    observationType: { type: String },                                                                               // 8
    observationValue: { type: String },                                                                              // 9
    observationUnits: { type: String },                                                                              // 10
    observationStatus: { type: String },                                                                             // 11
    observationSource: { type: String },                                                                             // 12
    createdAt: { type: Date },                                                                                       // 13
    patientId: { type: String }                                                                                      // 14
  }).validator(),                                                                                                    // 7
  run: function run(document) {                                                                                      // 16
    Observations.insert(document);                                                                                   // 17
  }                                                                                                                  // 18
});                                                                                                                  // 5
                                                                                                                     //
var updateObservation = new ValidatedMethod({                                                                        // 21
  name: 'observations.update',                                                                                       // 22
  validate: new SimpleSchema({                                                                                       // 23
    _id: { type: String },                                                                                           // 24
    'update.observationType': { type: String, optional: true },                                                      // 25
    'update.observationValue': { type: String, optional: true },                                                     // 26
    'update.observationUnits': { type: String, optional: true },                                                     // 27
    'update.observationStatus': { type: String, optional: true },                                                    // 28
    'update.observationSource': { type: String, optional: true },                                                    // 29
    'update.patientId': { type: String, optional: true }                                                             // 30
  }).validator(),                                                                                                    // 23
  run: function run(_ref) {                                                                                          // 32
    var _id = _ref._id;                                                                                              // 32
    var update = _ref.update;                                                                                        // 32
                                                                                                                     //
    Observations.update(_id, { $set: update });                                                                      // 33
  }                                                                                                                  // 34
});                                                                                                                  // 21
                                                                                                                     //
var removeObservation = new ValidatedMethod({                                                                        // 37
  name: 'observations.remove',                                                                                       // 38
  validate: new SimpleSchema({                                                                                       // 39
    _id: { type: String }                                                                                            // 40
  }).validator(),                                                                                                    // 39
  run: function run(_ref2) {                                                                                         // 42
    var _id = _ref2._id;                                                                                             // 42
                                                                                                                     //
    Observations.remove(_id);                                                                                        // 43
  }                                                                                                                  // 44
});                                                                                                                  // 37
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"observations.js":["faker","meteor/mongo","meteor/aldeed:simple-schema","meteor/dburles:factory",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/observations/observations.js                                                                          //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({Observations:function(){return Observations}});var faker;module.import('faker',{"default":function(v){faker=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var Factory;module.import('meteor/dburles:factory',{"Factory":function(v){Factory=v}});
                                                                                                                     // 2
                                                                                                                     // 3
                                                                                                                     // 4
                                                                                                                     //
var Observations = new Mongo.Collection('Observations');                                                             // 6
                                                                                                                     //
Observations.schema = new SimpleSchema({                                                                             // 8
  observationType: {                                                                                                 // 9
    type: String,                                                                                                    // 10
    label: 'The type of observation.'                                                                                // 11
  },                                                                                                                 // 9
  observationValue: {                                                                                                // 13
    type: String,                                                                                                    // 14
    label: 'The value of the observation.'                                                                           // 15
  },                                                                                                                 // 13
  observationUnits: {                                                                                                // 17
    type: String,                                                                                                    // 18
    label: 'The units of the observation'                                                                            // 19
  },                                                                                                                 // 17
  observationStatus: {                                                                                               // 21
    type: String,                                                                                                    // 22
    label: 'The status of the observation.'                                                                          // 23
  },                                                                                                                 // 21
  observationSource: {                                                                                               // 25
    type: String,                                                                                                    // 26
    label: 'The source of the observation.'                                                                          // 27
  },                                                                                                                 // 25
  createdAt: {                                                                                                       // 29
    type: Date,                                                                                                      // 30
    label: 'Date of the observation.'                                                                                // 31
  },                                                                                                                 // 29
  createdBy: {                                                                                                       // 33
    type: String,                                                                                                    // 34
    label: 'Creator of the observation.'                                                                             // 35
  },                                                                                                                 // 33
  patientId: {                                                                                                       // 37
    type: String,                                                                                                    // 38
    label: 'Patient ID of the observation.'                                                                          // 39
  }                                                                                                                  // 37
});                                                                                                                  // 8
                                                                                                                     //
Observations.attachSchema(Observations.schema);                                                                      // 43
                                                                                                                     //
Factory.define('observation', Observations, {                                                                        // 45
  title: function title() {                                                                                          // 46
    return "lorem ipsum...";                                                                                         // 46
  },                                                                                                                 // 46
  createdAt: function createdAt() {                                                                                  // 47
    return new Date();                                                                                               // 47
  }                                                                                                                  // 47
});                                                                                                                  // 45
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"patients":{"methods.js":["meteor/meteor","meteor/alanning:roles","meteor/accounts-base","meteor/aldeed:simple-schema","meteor/mdg:validated-method",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/patients/methods.js                                                                                   //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({insertPatient:function(){return insertPatient},updatePatient:function(){return updatePatient},removePatientById:function(){return removePatientById}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Roles;module.import('meteor/alanning:roles',{"Roles":function(v){Roles=v}});var Accounts;module.import('meteor/accounts-base',{"Accounts":function(v){Accounts=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var ValidatedMethod;module.import('meteor/mdg:validated-method',{"ValidatedMethod":function(v){ValidatedMethod=v}});
                                                                                                                     // 2
                                                                                                                     // 3
                                                                                                                     // 4
                                                                                                                     // 5
                                                                                                                     // 6
                                                                                                                     //
//import { Patients } from 'meteor/accounts-base';                                                                   //
                                                                                                                     //
var insertPatient = new ValidatedMethod({                                                                            // 11
  name: 'patients.insert',                                                                                           // 12
  validate: new SimpleSchema({                                                                                       // 13
    'name.$.text': { type: String },                                                                                 // 14
    'identifier': { type: [String], optional: true },                                                                // 15
    'gender': { type: String, optional: true },                                                                      // 16
    'active': { type: Boolean, optional: true },                                                                     // 17
    'birthdate': { type: Date, optional: true },                                                                     // 18
    'photo.$.url': { type: String, optional: true }                                                                  // 19
  }).validator(),                                                                                                    // 13
  run: function run(document) {                                                                                      // 21
                                                                                                                     //
    Patients.insert(document);                                                                                       // 23
  }                                                                                                                  // 24
});                                                                                                                  // 11
                                                                                                                     //
var updatePatient = new ValidatedMethod({                                                                            // 27
  name: 'patients.update',                                                                                           // 28
  validate: new SimpleSchema({                                                                                       // 29
    _id: { type: String },                                                                                           // 30
    'update': { type: Object, blackbox: true, optional: true }                                                       // 31
  }).validator(),                                                                                                    // 29
  run: function run(_ref) {                                                                                          // 33
    var _id = _ref._id;                                                                                              // 33
    var update = _ref.update;                                                                                        // 33
                                                                                                                     //
    console.log("updatePatient");                                                                                    // 34
    console.log("_id", _id);                                                                                         // 35
    console.log("update", update);                                                                                   // 36
                                                                                                                     //
    var patient = Patients.findOne({ _id: _id });                                                                    // 38
                                                                                                                     //
    delete patient._id;                                                                                              // 40
    delete patient._document;                                                                                        // 41
    delete patient._super_;                                                                                          // 42
    patient.name.text = update.name.text;                                                                            // 43
    patient.gender = update.gender;                                                                                  // 44
    patient.photo = update.gender.photo;                                                                             // 45
                                                                                                                     //
    console.log("diffedPatient", patient);                                                                           // 47
                                                                                                                     //
    Patients.update(_id, { $set: update });                                                                          // 50
  }                                                                                                                  // 51
});                                                                                                                  // 27
                                                                                                                     //
var removePatientById = new ValidatedMethod({                                                                        // 54
  name: 'patients.removeById',                                                                                       // 55
  validate: new SimpleSchema({                                                                                       // 56
    _id: { type: String }                                                                                            // 57
  }).validator(),                                                                                                    // 56
  run: function run(_ref2) {                                                                                         // 59
    var _id = _ref2._id;                                                                                             // 59
                                                                                                                     //
    console.log("Removing user " + _id);                                                                             // 60
    Patients.remove({ _id: _id });                                                                                   // 61
  }                                                                                                                  // 62
});                                                                                                                  // 54
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"practitioners":{"methods.js":["meteor/meteor","meteor/alanning:roles","meteor/accounts-base","meteor/aldeed:simple-schema","meteor/mdg:validated-method",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/practitioners/methods.js                                                                              //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({insertPractitioner:function(){return insertPractitioner},updatePractitioner:function(){return updatePractitioner},removePractitionerById:function(){return removePractitionerById}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Roles;module.import('meteor/alanning:roles',{"Roles":function(v){Roles=v}});var Accounts;module.import('meteor/accounts-base',{"Accounts":function(v){Accounts=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var ValidatedMethod;module.import('meteor/mdg:validated-method',{"ValidatedMethod":function(v){ValidatedMethod=v}});
                                                                                                                     // 2
                                                                                                                     // 3
                                                                                                                     // 4
                                                                                                                     // 5
                                                                                                                     // 6
                                                                                                                     //
var insertPractitioner = new ValidatedMethod({                                                                       // 8
  name: 'practitioners.insert',                                                                                      // 9
  validate: new SimpleSchema({                                                                                       // 10
    'name.text': { type: String },                                                                                   // 11
    'identifier': { type: [String], optional: true },                                                                // 12
    'gender': { type: String, optional: true },                                                                      // 13
    'active': { type: Boolean, optional: true },                                                                     // 14
    'photo.$.url': { type: String, optional: true }                                                                  // 15
  }).validator(),                                                                                                    // 10
  run: function run(document) {                                                                                      // 17
    console.log("insertPractitioner");                                                                               // 18
    console.log("document", document);                                                                               // 19
                                                                                                                     //
    Practitioners.insert(document);                                                                                  // 21
  }                                                                                                                  // 22
});                                                                                                                  // 8
                                                                                                                     //
var updatePractitioner = new ValidatedMethod({                                                                       // 25
  name: 'practitioners.update',                                                                                      // 26
  validate: new SimpleSchema({                                                                                       // 27
    '_id': { type: String },                                                                                         // 28
    'update': { type: Object, blackbox: true, optional: true }                                                       // 29
  }).validator(),                                                                                                    // 27
  run: function run(_ref) {                                                                                          // 31
    var _id = _ref._id;                                                                                              // 31
    var update = _ref.update;                                                                                        // 31
                                                                                                                     //
    console.log("updatePractitioner");                                                                               // 32
    console.log("_id", _id);                                                                                         // 33
    console.log("update", update);                                                                                   // 34
                                                                                                                     //
    var practitioner = Practitioners.findOne({ _id: _id });                                                          // 36
                                                                                                                     //
    delete practitioner._id;                                                                                         // 38
    delete practitioner._document;                                                                                   // 39
    delete practitioner._super_;                                                                                     // 40
    practitioner.gender = update.gender;                                                                             // 41
    practitioner.photo.push({                                                                                        // 42
      url: update.gender.photo                                                                                       // 43
    });                                                                                                              // 42
    practitioner.name.push({                                                                                         // 45
      text: update.name.text                                                                                         // 46
    });                                                                                                              // 45
                                                                                                                     //
    console.log("differedPractitioner", practitioner);                                                               // 49
                                                                                                                     //
    Practitioners.update(_id, { $set: practitioner });                                                               // 52
  }                                                                                                                  // 53
});                                                                                                                  // 25
                                                                                                                     //
var removePractitionerById = new ValidatedMethod({                                                                   // 56
  name: 'practitioners.removeById',                                                                                  // 57
  validate: new SimpleSchema({                                                                                       // 58
    '_id': { type: String }                                                                                          // 59
  }).validator(),                                                                                                    // 58
  run: function run(_ref2) {                                                                                         // 61
    var _id = _ref2._id;                                                                                             // 61
                                                                                                                     //
    console.log("Removing user " + _id);                                                                             // 62
    Practitioners.remove({ _id: _id });                                                                              // 63
  }                                                                                                                  // 64
});                                                                                                                  // 56
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"users":{"methods.js":["meteor/meteor","meteor/alanning:roles","meteor/accounts-base","meteor/aldeed:simple-schema","meteor/mdg:validated-method",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/users/methods.js                                                                                      //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({insertUser:function(){return insertUser},updateUser:function(){return updateUser},removeUserById:function(){return removeUserById},setUserAvatar:function(){return setUserAvatar},setUserTheme:function(){return setUserTheme},changeUserPassword:function(){return changeUserPassword}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Roles;module.import('meteor/alanning:roles',{"Roles":function(v){Roles=v}});var Accounts;module.import('meteor/accounts-base',{"Accounts":function(v){Accounts=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var ValidatedMethod;module.import('meteor/mdg:validated-method',{"ValidatedMethod":function(v){ValidatedMethod=v}});
                                                                                                                     // 2
                                                                                                                     // 3
                                                                                                                     // 4
                                                                                                                     // 5
                                                                                                                     // 6
                                                                                                                     //
var insertUser = new ValidatedMethod({                                                                               // 8
  name: 'users.insert',                                                                                              // 9
  validate: function validate() {                                                                                    // 10
    return true;                                                                                                     // 11
  },                                                                                                                 // 12
  // validate: new SimpleSchema({                                                                                    //
  //   title: { type: String },                                                                                      //
  //   createdAt: { type: Date },                                                                                    //
  // }).validator(),                                                                                                 //
  run: function run(document) {                                                                                      // 17
    Meteor.users.insert(document);                                                                                   // 18
  }                                                                                                                  // 19
});                                                                                                                  // 8
                                                                                                                     //
var updateUser = new ValidatedMethod({                                                                               // 22
  name: 'users.update',                                                                                              // 23
  validate: function validate() {                                                                                    // 24
    return true;                                                                                                     // 25
  },                                                                                                                 // 26
  // validate: new SimpleSchema({                                                                                    //
  //   _id: { type: String },                                                                                        //
  //   'update.title': { type: String, optional: true },                                                             //
  // }).validator(),                                                                                                 //
  run: function run(_ref) {                                                                                          // 31
    var _id = _ref._id;                                                                                              // 31
    var update = _ref.update;                                                                                        // 31
                                                                                                                     //
    Meteor.users.update(_id, { $set: update });                                                                      // 32
  }                                                                                                                  // 33
});                                                                                                                  // 22
                                                                                                                     //
var removeUserById = new ValidatedMethod({                                                                           // 36
  name: 'users.removeById',                                                                                          // 37
  validate: new SimpleSchema({                                                                                       // 38
    _id: { type: String }                                                                                            // 39
  }).validator(),                                                                                                    // 38
  run: function run(_ref2) {                                                                                         // 41
    var _id = _ref2._id;                                                                                             // 41
                                                                                                                     //
    console.log("Removing user " + _id);                                                                             // 42
    Meteor.users.remove({ _id: _id });                                                                               // 43
  }                                                                                                                  // 44
});                                                                                                                  // 36
                                                                                                                     //
var setUserAvatar = new ValidatedMethod({                                                                            // 48
  name: 'users.setAvatar',                                                                                           // 49
  validate: new SimpleSchema({                                                                                       // 50
    _id: { type: String },                                                                                           // 51
    avatar: { type: String }                                                                                         // 52
  }).validator(),                                                                                                    // 50
  run: function run(_ref3) {                                                                                         // 54
    var _id = _ref3._id;                                                                                             // 54
    var avatar = _ref3.avatar;                                                                                       // 54
                                                                                                                     //
    Meteor.users.update(_id, { $set: { 'profile.avatar': avatar } });                                                // 55
  }                                                                                                                  // 56
});                                                                                                                  // 48
                                                                                                                     //
var setUserTheme = new ValidatedMethod({                                                                             // 59
  name: 'users.setTheme',                                                                                            // 60
  validate: new SimpleSchema({                                                                                       // 61
    _id: { type: String },                                                                                           // 62
    backgroundColor: { type: String, optional: true },                                                               // 63
    backgroundImagePath: { type: String, optional: true },                                                           // 64
    video: { type: String, optional: true }                                                                          // 65
  }).validator(),                                                                                                    // 61
  run: function run(_ref4) {                                                                                         // 67
    var _id = _ref4._id;                                                                                             // 67
    var backgroundColor = _ref4.backgroundColor;                                                                     // 67
    var backgroundImagePath = _ref4.backgroundImagePath;                                                             // 67
                                                                                                                     //
                                                                                                                     //
    Meteor.users.update(_id, { $unset: {                                                                             // 69
        'profile.theme.backgroundImagePath': "",                                                                     // 70
        'profile.theme.backgroundColor': ""                                                                          // 71
      } });                                                                                                          // 69
                                                                                                                     //
    if (backgroundColor) {                                                                                           // 74
      Meteor.users.update(_id, { $set: {                                                                             // 75
          'profile.theme.backgroundColor': backgroundColor                                                           // 76
        } });                                                                                                        // 75
    }                                                                                                                // 78
                                                                                                                     //
    if (backgroundImagePath) {                                                                                       // 80
      Meteor.users.update(_id, { $set: {                                                                             // 81
          'profile.theme.backgroundImagePath': backgroundImagePath                                                   // 82
        } });                                                                                                        // 81
    }                                                                                                                // 84
  }                                                                                                                  // 86
});                                                                                                                  // 59
                                                                                                                     //
var changeUserPassword = new ValidatedMethod({                                                                       // 89
  name: 'users.changePassword',                                                                                      // 90
  validate: new SimpleSchema({                                                                                       // 91
    _id: { type: String },                                                                                           // 92
    password: { type: String }                                                                                       // 93
  }).validator(),                                                                                                    // 91
  run: function run(_ref5) {                                                                                         // 95
    var _id = _ref5._id;                                                                                             // 95
    var avatar = _ref5.avatar;                                                                                       // 95
                                                                                                                     //
    Meteor.users.update(_id, { $set: { 'profile.avatar': avatar } });                                                // 96
  }                                                                                                                  // 97
});                                                                                                                  // 89
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"startup":{"server":{"accounts":{"email-templates.js":["meteor/accounts-base",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/startup/server/accounts/email-templates.js                                                                //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var Accounts;module.import('meteor/accounts-base',{"Accounts":function(v){Accounts=v}});                             // 1
                                                                                                                     //
var name = 'Application Name';                                                                                       // 3
var email = '<support@application.com>';                                                                             // 4
var from = name + ' ' + email;                                                                                       // 5
var emailTemplates = Accounts.emailTemplates;                                                                        // 6
                                                                                                                     //
emailTemplates.siteName = name;                                                                                      // 8
emailTemplates.from = from;                                                                                          // 9
                                                                                                                     //
emailTemplates.resetPassword = {                                                                                     // 11
  subject: function subject() {                                                                                      // 12
    return '[' + name + '] Reset Your Password';                                                                     // 13
  },                                                                                                                 // 14
  text: function text(user, url) {                                                                                   // 15
    var userEmail = user.emails[0].address;                                                                          // 16
    var urlWithoutHash = url.replace('#/', '');                                                                      // 17
                                                                                                                     //
    return 'A password reset has been requested for the account related to this\n    address (' + userEmail + '). To reset the password, visit the following link:\n    \n\n' + urlWithoutHash + '\n\n If you did not request this reset, please ignore\n    this email. If you feel something is wrong, please contact our support team:\n    ' + email + '.';
  }                                                                                                                  // 24
};                                                                                                                   // 11
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"api.js":["/imports/api/documents/server/publications.js","/imports/api/posts/server/publications.js","/imports/api/topics/server/publications.js","/imports/api/statistics/server/publications.js","/imports/api/documents/methods.js","/imports/api/posts/methods.js","/imports/api/patients/methods.js","/imports/api/practitioners/methods.js","/imports/api/topics/methods.js","/imports/api/devices/methods.js","/imports/api/observations/methods.js",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/startup/server/api.js                                                                                     //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.import('/imports/api/documents/server/publications.js');module.import('/imports/api/posts/server/publications.js');module.import('/imports/api/topics/server/publications.js');module.import('/imports/api/statistics/server/publications.js');module.import('/imports/api/documents/methods.js');module.import('/imports/api/posts/methods.js');module.import('/imports/api/patients/methods.js');module.import('/imports/api/practitioners/methods.js');module.import('/imports/api/topics/methods.js');module.import('/imports/api/devices/methods.js');module.import('/imports/api/observations/methods.js');
// publications                                                                                                      //
                                                                                                                     // 3
                                                                                                                     // 4
                                                                                                                     // 5
                                                                                                                     // 6
                                                                                                                     //
// methods                                                                                                           //
                                                                                                                     // 9
                                                                                                                     // 10
                                                                                                                     // 11
                                                                                                                     // 12
                                                                                                                     // 13
                                                                                                                     // 14
                                                                                                                     // 15
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"browser-policy.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/startup/server/browser-policy.js                                                                          //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
// import { BrowserPolicy } from 'meteor/browser-policy-common';                                                     //
// e.g., BrowserPolicy.content.allowOriginForAll( 's3.amazonaws.com' );                                              //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"fixtures.js":["meteor/meteor","meteor/alanning:roles","meteor/accounts-base","/imports/api/devices/devices","/imports/api/observations/observations",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/startup/server/fixtures.js                                                                                //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Roles;module.import('meteor/alanning:roles',{"Roles":function(v){Roles=v}});var Accounts;module.import('meteor/accounts-base',{"Accounts":function(v){Accounts=v}});var Devices;module.import('/imports/api/devices/devices',{"Devices":function(v){Devices=v}});var Observations;module.import('/imports/api/observations/observations',{"Observations":function(v){Observations=v}});
                                                                                                                     // 2
                                                                                                                     // 3
                                                                                                                     // 4
                                                                                                                     // 5
                                                                                                                     //
var lastUser;                                                                                                        // 7
                                                                                                                     //
var users = [{                                                                                                       // 9
  email: 'admin@admin.com',                                                                                          // 10
  password: 'password',                                                                                              // 11
  profile: {                                                                                                         // 12
    name: [{ given: 'Abigail', family: 'Watson', text: 'Abigail Watson' }],                                          // 13
    avatar: "https://media.licdn.com/mpr/mpr/shrink_100_100/AAEAAQAAAAAAAAKeAAAAJDJkM2RmNTMzLWI4OGUtNDZmOC1iNTliLWYwOTc1ZWM0YmIyZg.jpg",
    birthdate: "1978/01/25"                                                                                          // 15
  },                                                                                                                 // 12
  roles: ['admin']                                                                                                   // 17
}, {                                                                                                                 // 9
  email: 'bobnix@gmail.com',                                                                                         // 20
  password: 'test1234',                                                                                              // 21
  profile: {                                                                                                         // 22
    name: [{ given: 'Bob', family: 'NixPatient', text: 'Bob NixPatient' }],                                          // 23
    avatar: "https://media.licdn.com/mpr/mpr/shrink_100_100/AAEAAQAAAAAAAAKeAAAAJDJkM2RmNTMzLWI4OGUtNDZmOC1iNTliLWYwOTc1ZWM0YmIyZg.jpg",
    birthdate: "1958/05/02"                                                                                          // 25
  },                                                                                                                 // 22
  roles: ['patient']                                                                                                 // 27
}, {                                                                                                                 // 19
  email: 'admin2@admin.com',                                                                                         // 30
  password: 'password',                                                                                              // 31
  profile: {                                                                                                         // 32
    name: [{ given: 'Bob', family: 'Nix', text: 'Bob Nix' }],                                                        // 33
    avatar: "https://media.licdn.com/mpr/mpr/shrink_100_100/AAEAAQAAAAAAAAKeAAAAJDJkM2RmNTMzLWI4OGUtNDZmOC1iNTliLWYwOTc1ZWM0YmIyZg.jpg",
    birthdate: "1958/05/02"                                                                                          // 35
  },                                                                                                                 // 32
  roles: ['admin']                                                                                                   // 37
}];                                                                                                                  // 29
                                                                                                                     //
users.forEach(function (_ref) {                                                                                      // 40
  var email = _ref.email;                                                                                            // 40
  var password = _ref.password;                                                                                      // 40
  var profile = _ref.profile;                                                                                        // 40
  var roles = _ref.roles;                                                                                            // 40
                                                                                                                     //
  var userExists = Meteor.users.findOne({ 'emails.address': email });                                                // 41
  lastUser = userExists;                                                                                             // 42
                                                                                                                     //
  if (!userExists) {                                                                                                 // 44
    var _userId = Accounts.createUser({ email: email, password: password, profile: profile });                       // 45
    lastUser = _userId;                                                                                              // 46
    Roles.addUsersToRoles(_userId, roles);                                                                           // 47
  }                                                                                                                  // 48
});                                                                                                                  // 49
                                                                                                                     //
if (process.env.INITIALIZE) {                                                                                        // 51
  console.info('no devices in database!  adding some default devices');                                              // 52
                                                                                                                     //
  var userId = null;                                                                                                 // 54
  var devices = [{                                                                                                   // 55
    deviceName: 'FakeBreathalyzer',                                                                                  // 57
    deviceProductId: '0000-0001'                                                                                     // 58
  }, {                                                                                                               // 56
    deviceName: 'FakeBreathalyzer',                                                                                  // 61
    deviceProductId: '0000-0002'                                                                                     // 62
  }, {                                                                                                               // 60
    deviceName: 'FakeBreathalyzer',                                                                                  // 65
    deviceProductId: '0000-0003'                                                                                     // 66
  }];                                                                                                                // 64
                                                                                                                     //
  if (process.env.Devices) {                                                                                         // 70
    if (Devices.find().count() === 0 || process.env.ADDITIONAL) {                                                    // 71
      var patient = Patients.findOne({ "name.text": "Alan Turing" });                                                // 72
      if (patient) {                                                                                                 // 73
        for (var i = 0, len = devices.length; i < len; i++) {                                                        // 74
          var device = devices[i];                                                                                   // 75
          console.info("Initializing device %s, %s, %s", device.deviceName, device.deviceProductId, patient._id);    // 76
          deviceId = Devices.insert({                                                                                // 77
            deviceName: device.deviceName,                                                                           // 78
            deviceProductId: device.deviceProductId,                                                                 // 79
            patientId: patient._id,                                                                                  // 80
            createdAt: new Date(),                                                                                   // 81
            createdBy: lastUser.emails[0].address                                                                    // 82
          });                                                                                                        // 77
        }                                                                                                            // 84
      } else {                                                                                                       // 85
        console.info("Initializing devices - no patient");                                                           // 86
      }                                                                                                              // 87
    }                                                                                                                // 88
  }                                                                                                                  // 89
}                                                                                                                    // 90
                                                                                                                     //
if (process.env.INITIALIZE) {                                                                                        // 92
  console.info('no observations in database!  adding some default observations');                                    // 93
                                                                                                                     //
  var userId = null;                                                                                                 // 95
  var observations = [{                                                                                              // 96
    observationType: 'BAC',                                                                                          // 98
    observationValue: '0.08',                                                                                        // 99
    observationUnits: 'mg/dL',                                                                                       // 100
    observationStatus: 'OK',                                                                                         // 101
    observationSource: 'TestData'                                                                                    // 102
  }, {                                                                                                               // 97
    observationType: 'BAC',                                                                                          // 105
    observationValue: '0.023',                                                                                       // 106
    observationUnits: 'mg/dL',                                                                                       // 107
    observationStatus: 'OK',                                                                                         // 108
    observationSource: 'TestData'                                                                                    // 109
  }, {                                                                                                               // 104
    observationType: 'BAC',                                                                                          // 112
    observationValue: '0.011',                                                                                       // 113
    observationUnits: 'mg/dL',                                                                                       // 114
    observationStatus: 'OK',                                                                                         // 115
    observationSource: 'TestData'                                                                                    // 116
  }];                                                                                                                // 111
                                                                                                                     //
  if (process.env.Observations) {                                                                                    // 120
    if (Observations.find().count() === 0 || process.env.ADDITIONAL) {                                               // 121
      var patient = Patients.findOne({ "name.text": "Alan Turing" });                                                // 122
      if (patient) {                                                                                                 // 123
        for (var i = 0, len = observations.length; i < len; i++) {                                                   // 124
          var observation = observations[i];                                                                         // 125
          console.info("Initializing observation %s, %s,%s, %s, %s", observation.observationType, observation.observationValue, observation.observationUnits, observation.observationStatus, observation.observationSource, patient._id);
          observationId = Observations.insert({                                                                      // 128
            observationType: observation.observationType,                                                            // 129
            observationValue: observation.observationValue,                                                          // 130
            observationUnits: observation.observationUnits,                                                          // 131
            observationStatus: observation.observationStatus,                                                        // 132
            observationSource: observation.observationSource,                                                        // 133
            patientId: patient._id,                                                                                  // 134
            createdAt: new Date(),                                                                                   // 135
            createdBy: lastUser.emails[0].address                                                                    // 136
          });                                                                                                        // 128
        }                                                                                                            // 138
      } else {                                                                                                       // 139
        console.info("Initializing observations - no patient");                                                      // 140
      }                                                                                                              // 141
    }                                                                                                                // 142
  }                                                                                                                  // 143
}                                                                                                                    // 144
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"index.js":["./accounts/email-templates","./browser-policy","./fixtures","./api",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/startup/server/index.js                                                                                   //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.import('./accounts/email-templates');module.import('./browser-policy');module.import('./fixtures');module.import('./api');
                                                                                                                     // 2
                                                                                                                     // 3
                                                                                                                     // 4
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}}},"server":{"cron.js":["/imports/api/posts/posts","/imports/api/topics/topics","/imports/api/statistics/statistics","meteor/meteor",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/cron.js                                                                                                    //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var Posts;module.import('/imports/api/posts/posts',{"Posts":function(v){Posts=v}});var Topics;module.import('/imports/api/topics/topics',{"Topics":function(v){Topics=v}});var Statistics;module.import('/imports/api/statistics/statistics',{"Statistics":function(v){Statistics=v}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});
                                                                                                                     // 2
                                                                                                                     // 3
                                                                                                                     //
                                                                                                                     // 5
                                                                                                                     //
var DailyStats = {                                                                                                   // 7
  generate: function generate() {                                                                                    // 8
    var newDailyStat = {                                                                                             // 9
      date: new Date(),                                                                                              // 10
      usersCount: Meteor.users.find().count(),                                                                       // 11
      postsCount: Posts.find().count(),                                                                              // 12
      topicsCount: Topics.find().count(),                                                                            // 13
      patientsCount: Patients.find().count(),                                                                        // 14
      practitionersCount: Practitioners.find().count()                                                               // 15
    };                                                                                                               // 9
    console.log('newDailyStat', newDailyStat);                                                                       // 17
                                                                                                                     //
    return Statistics.insert(newDailyStat);                                                                          // 19
  }                                                                                                                  // 20
};                                                                                                                   // 7
                                                                                                                     //
SyncedCron.add({                                                                                                     // 23
  name: 'Crunch some important numbers for the marketing department',                                                // 24
  schedule: function schedule(parser) {                                                                              // 25
    // return parser.text('at 12:00 am');                                                                            //
    return parser.text('every 1 hour');                                                                              // 27
  },                                                                                                                 // 28
  job: function job() {                                                                                              // 29
    DailyStats.generate();                                                                                           // 30
  }                                                                                                                  // 31
});                                                                                                                  // 23
                                                                                                                     //
Meteor.methods({                                                                                                     // 35
  generateDailyStat: function generateDailyStat() {                                                                  // 36
    if (process.env.NODE_ENV !== 'production') {                                                                     // 37
      DailyStats.generate();                                                                                         // 38
    }                                                                                                                // 39
  }                                                                                                                  // 40
});                                                                                                                  // 35
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"initialize.users.js":["meteor/accounts-base","meteor/meteor",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/initialize.users.js                                                                                        //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var Accounts;module.import('meteor/accounts-base',{"Accounts":function(v){Accounts=v}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});
// https://www.hl7.org/fhir/riskassessment-example-prognosis.json.html                                               //
// https://www.hl7.org/fhir/riskassessment-example-cardiac.json.html                                                 //
                                                                                                                     // 4
                                                                                                                     // 5
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"methods.users.js":["meteor/accounts-base","meteor/meteor",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/methods.users.js                                                                                           //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var Accounts;module.import('meteor/accounts-base',{"Accounts":function(v){Accounts=v}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});
                                                                                                                     // 2
                                                                                                                     //
Meteor.startup(function () {                                                                                         // 5
  if (process.env.INITIALIZE && Meteor.users.find().count() === 0) {                                                 // 6
    console.log('No users found.');                                                                                  // 7
                                                                                                                     //
    Meteor.call('initializeTestUsers');                                                                              // 9
  }                                                                                                                  // 10
});                                                                                                                  // 11
                                                                                                                     //
// Support for playing D&D: Roll 3d6 for dexterity                                                                   //
Accounts.onCreateUser(function (options, user) {                                                                     // 14
  console.log('Accounts.onCreateUser');                                                                              // 15
                                                                                                                     //
  // We'll set the role manually                                                                                     //
  if (options.profile.accessCode && Meteor.settings && Meteor.settings['private'] && Meteor.settings['private'].accessCode) {
    if (options.profile.accessCode === Meteor.settings['private'].accessCode) {                                      // 19
      user.roles = ["practitioner"];                                                                                 // 20
    }                                                                                                                // 21
  }                                                                                                                  // 22
                                                                                                                     //
  // We still want the default hook's 'profile' behavior.                                                            //
  if (options.profile) user.profile = options.profile;                                                               // 25
  return user;                                                                                                       // 27
});                                                                                                                  // 28
                                                                                                                     //
Meteor.methods({                                                                                                     // 32
  verifyPractitioner: function verifyPractitioner(userId) {                                                          // 33
    check(userId, String);                                                                                           // 34
                                                                                                                     //
    return Roles.userIsInRole(userId, 'practitioner');                                                               // 36
  },                                                                                                                 // 37
  grantPractitionerAccess: function grantPractitionerAccess(userId, accessCode) {                                    // 38
    check(userId, String);                                                                                           // 39
    check(accessCode, String);                                                                                       // 40
    console.log('User ' + userId + ' submitted access code "' + accessCode + '".  Verifying access code...');        // 41
                                                                                                                     //
    //console.log('Meteor.settings.private.accessCode', Meteor.settings.private.accessCode);                         //
                                                                                                                     //
    if (Meteor.settings['private'].accessCode) {                                                                     // 45
      if (accessCode === Meteor.settings['private'].accessCode) {                                                    // 46
        console.log('Access code verified.  Granting practitioner access...');                                       // 47
        Roles.setUserRoles(userId, 'practitioner');                                                                  // 48
        Roles.addUsersToRoles(userId, 'practitioner');                                                               // 49
      }                                                                                                              // 50
    } else {                                                                                                         // 52
      console.log('No access code set.  Skipping access grant.');                                                    // 53
      console.log('Set Meteor.settings.private.accessCode to enable this feature.');                                 // 54
    }                                                                                                                // 55
  },                                                                                                                 // 57
  dropTestUsers: function dropTestUsers() {                                                                          // 58
    console.log('Dropping test users...');                                                                           // 59
                                                                                                                     //
    if (process.env.NODE_ENV === 'test' || process.env.NODE_ENV === 'circle') {                                      // 61
      (function () {                                                                                                 // 61
        var count = 0;                                                                                               // 62
        Meteor.users.find().forEach(function (user) {                                                                // 63
          if (user.emails && user.emails[0]) {                                                                       // 64
            if (user.emails[0].address === 'alice@test.org' || user.emails[0].address === 'janedoe@test.org' || user.emails[0].address === 'admin@admin.com') {
              Meteor.users.remove({ _id: user._id });                                                                // 66
              count++;                                                                                               // 67
            }                                                                                                        // 68
          }                                                                                                          // 69
        });                                                                                                          // 70
        console.log(count + ' users removed.');                                                                      // 71
      })();                                                                                                          // 61
    } else {                                                                                                         // 73
      console.log('Not in test mode.  Try using NODE_ENV=test');                                                     // 74
    }                                                                                                                // 75
  },                                                                                                                 // 76
  updateUserProfile: function updateUserProfile(userId, profileData) {                                               // 77
    check(userId, String);                                                                                           // 78
    check(profileData, Object);                                                                                      // 79
                                                                                                                     //
    console.log('Updating user profile...', profileData);                                                            // 81
                                                                                                                     //
    Meteor.users.update({ _id: userId }, { $set: { profile: profileData } }, function (error, result) {              // 83
      if (error) {                                                                                                   // 84
        HipaaLogger.logEvent('error', Meteor.userId(), Meteor.user().getPrimaryEmail(), 'RiskAssessments', null, null, null, error);
      }                                                                                                              // 86
      if (result) {                                                                                                  // 87
        HipaaLogger.logEvent('update', Meteor.userId(), Meteor.user().getPrimaryEmail(), 'Meteor.users', null, null, null, null);
      }                                                                                                              // 89
    });                                                                                                              // 90
  },                                                                                                                 // 91
  initializeUser: function initializeUser(email, password, firstName, lastName) {                                    // 92
    check(email, String);                                                                                            // 93
    check(password, String);                                                                                         // 94
    check(firstName, String);                                                                                        // 95
    check(lastName, String);                                                                                         // 96
                                                                                                                     //
    console.log('Initializing user ' + email);                                                                       // 98
                                                                                                                     //
    if (Meteor.users.find({ 'emails.0.address': email }).count() === 0) {                                            // 100
      var newUserId = Accounts.createUser({                                                                          // 101
        email: email,                                                                                                // 102
        password: password,                                                                                          // 103
        profile: {                                                                                                   // 104
          name: {                                                                                                    // 105
            text: firstName + ' ' + lastName,                                                                        // 106
            given: firstName,                                                                                        // 107
            family: lastName                                                                                         // 108
          }                                                                                                          // 105
        }                                                                                                            // 104
      });                                                                                                            // 101
                                                                                                                     //
      if (newUserId) {                                                                                               // 113
        console.log('User created with ID ' + newUserId);                                                            // 114
      }                                                                                                              // 115
    } else {                                                                                                         // 116
      console.log("User with email already exists; skipping.");                                                      // 117
    }                                                                                                                // 118
  },                                                                                                                 // 119
  initializeTestUsers: function initializeTestUsers() {                                                              // 120
    console.log('Initializing users...');                                                                            // 121
                                                                                                                     //
    //==============================================================================                                 //
    // JANEDOE                                                                                                       //
                                                                                                                     //
    if (Meteor.users.find({ 'emails.0.address': 'janedoe@test.org' }).count() === 0) {                               // 126
      Accounts.createUser({                                                                                          // 127
        email: 'janedoe@test.org',                                                                                   // 128
        password: 'janedoe123',                                                                                      // 129
        profile: {                                                                                                   // 130
          name: {                                                                                                    // 131
            text: 'Jane Doe',                                                                                        // 132
            given: 'Jane',                                                                                           // 133
            family: 'Doe'                                                                                            // 134
          }                                                                                                          // 131
        }                                                                                                            // 130
      });                                                                                                            // 127
    }                                                                                                                // 138
                                                                                                                     //
    //==============================================================================                                 //
    // ADMIN                                                                                                         //
                                                                                                                     //
    if (Meteor.users.find({ 'emails.0.address': 'admin' }).count() === 0) {                                          // 144
      Accounts.createUser({                                                                                          // 145
        password: 'admin123',                                                                                        // 146
        email: 'admin@admin.com',                                                                                    // 147
        profile: {                                                                                                   // 148
          name: {                                                                                                    // 149
            text: 'System Admin',                                                                                    // 150
            given: 'System',                                                                                         // 151
            family: 'Admin'                                                                                          // 152
          }                                                                                                          // 149
        }                                                                                                            // 148
      });                                                                                                            // 145
    }                                                                                                                // 156
  }                                                                                                                  // 157
});                                                                                                                  // 32
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"main.js":["/imports/startup/server","/imports/api/users/methods","/imports/api/practitioners/methods","/imports/api/patients/methods","meteor/accounts-base","meteor/meteor",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/main.js                                                                                                    //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.import('/imports/startup/server');module.import('/imports/api/users/methods');module.import('/imports/api/practitioners/methods');module.import('/imports/api/patients/methods');var Accounts;module.import('meteor/accounts-base',{"Accounts":function(v){Accounts=v}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});
                                                                                                                     //
                                                                                                                     // 3
                                                                                                                     // 4
                                                                                                                     // 5
                                                                                                                     //
                                                                                                                     // 7
                                                                                                                     // 8
                                                                                                                     //
Meteor.startup(function () {                                                                                         // 10
  Meteor.call('initializeUser', 'janedoe@test.org', 'janedoe123', 'Jane', 'Doe');                                    // 11
});                                                                                                                  // 12
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"shared":{"collections.js":["/imports/api/statistics/statistics","meteor/meteor",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// shared/collections.js                                                                                             //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var Statistics;module.import('/imports/api/statistics/statistics',{"Statistics":function(v){Statistics=v}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});
                                                                                                                     // 2
                                                                                                                     //
// INSECURE; DELETE ME                                                                                               //
if (Meteor.isClient) {                                                                                               // 5
  Meteor.subscribe('allPractitioners');                                                                              // 6
  Meteor.subscribe('statistics');                                                                                    // 7
}                                                                                                                    // 8
                                                                                                                     //
// INSECURE; DELETE ME                                                                                               //
if (Meteor.isServer) {                                                                                               // 11
  Meteor.publish('allPractitioners', function (argument) {                                                           // 12
    return Practitioners.find();                                                                                     // 13
  });                                                                                                                // 14
  Meteor.publish('statistics', function () {                                                                         // 15
    Statistics.find({}, { limit: 90 });                                                                              // 16
  });                                                                                                                // 17
}                                                                                                                    // 18
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json",".jsx"]});
require("./lib/plugin/cordova-plugin-bactrack/www/bactrack.js");
require("./server/cron.js");
require("./server/initialize.users.js");
require("./server/methods.users.js");
require("./shared/collections.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
