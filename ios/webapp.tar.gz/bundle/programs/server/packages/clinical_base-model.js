(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var _ = Package.underscore._;
var ServerTime = Package['socialize:server-time'].ServerTime;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var CollectionHooks = Package['matb33:collection-hooks'].CollectionHooks;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var Log = Package.logging.Log;
var Tracker = Package.deps.Tracker;
var Deps = Package.deps.Deps;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var check = Package.check.check;
var Match = Package.check.Match;
var Random = Package.random.Random;
var EJSON = Package.ejson.EJSON;
var Collection2 = Package['aldeed:collection2-core'].Collection2;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var BaseModel;

(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/clinical_base-model/packages/clinical_base-model.js                                                      //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// packages/clinical:base-model/lib/BaseModel.js                                                              //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
if (typeof Object.create !== 'function') {                                                                    // 1
  Object.create = (function () {                                                                              // 2
    var thing = function () {};                                                                               // 3
    return function (prototype) {                                                                             // 4
      if (arguments.length > 1) {                                                                             // 5
        throw Error('Second argument not supported');                                                         // 6
      }                                                                                                       // 7
      if (typeof prototype !== 'object') {                                                                    // 8
        throw TypeError('Argument must be an object');                                                        // 9
      }                                                                                                       // 10
      thing.prototype = prototype;                                                                            // 11
      var result = new thing();                                                                               // 12
      thing.prototype = null;                                                                                 // 13
      return result;                                                                                          // 14
    };                                                                                                        // 15
  })();                                                                                                       // 16
}                                                                                                             // 17
                                                                                                              // 18
var diff = function (a, b) {                                                                                  // 19
  var keys = _.map(a, function (v, k) {                                                                       // 20
    if (b[k] === v) {                                                                                         // 21
      return k;                                                                                               // 22
    }                                                                                                         // 23
  });                                                                                                         // 24
  return _.omit(a, keys);                                                                                     // 25
};                                                                                                            // 26
                                                                                                              // 27
                                                                                                              // 28
                                                                                                              // 29
/*globals BaseModel:true*/                                                                                    // 30
                                                                                                              // 31
BaseModel = function () {};                                                                                   // 32
                                                                                                              // 33
BaseModel.createEmpty = function (_id) {                                                                      // 34
  return new this({                                                                                           // 35
    _id: _id                                                                                                  // 36
  });                                                                                                         // 37
};                                                                                                            // 38
                                                                                                              // 39
BaseModel.extend = function () {                                                                              // 40
  var child = function (document) {                                                                           // 41
    _.extend(this, document);                                                                                 // 42
    this._document = document;                                                                                // 43
  };                                                                                                          // 44
                                                                                                              // 45
  //add Static properties and methods                                                                         // 46
  _.extend(child, this);                                                                                      // 47
                                                                                                              // 48
  //prototypal inheritence                                                                                    // 49
  child.prototype = Object.create(this.prototype);                                                            // 50
  child.prototype.constructor = child;                                                                        // 51
                                                                                                              // 52
  //access to parent                                                                                          // 53
  child.prototype._parent_ = this;                                                                            // 54
  child.prototype._super_ = this.prototype;                                                                   // 55
                                                                                                              // 56
  return child;                                                                                               // 57
};                                                                                                            // 58
                                                                                                              // 59
BaseModel.extendAndSetupCollection = function (collectionName) {                                              // 60
  var model = this.extend();                                                                                  // 61
                                                                                                              // 62
  model.collection = model.prototype._collection = new Mongo.Collection(collectionName, {                     // 63
    transform: function (document) {                                                                          // 64
      return new model(document);                                                                             // 65
    }                                                                                                         // 66
  });                                                                                                         // 67
                                                                                                              // 68
  Meteor[collectionName] = model.collection;                                                                  // 69
                                                                                                              // 70
  return model;                                                                                               // 71
};                                                                                                            // 72
                                                                                                              // 73
BaseModel.appendSchema = function (schemaObject) {                                                            // 74
  var schema = new SimpleSchema(schemaObject);                                                                // 75
  var collection = this.prototype._collection;                                                                // 76
                                                                                                              // 77
  if (collection) {                                                                                           // 78
    collection.attachSchema(schema);                                                                          // 79
    this.prototype._validator = schema.newContext();                                                          // 80
  } else {                                                                                                    // 81
    throw new Error(                                                                                          // 82
      "Can't append schema to non existent collection. Either use extendAndSetupCollection() or assign a collection to Model.prototype._collection"
    );                                                                                                        // 84
  }                                                                                                           // 85
};                                                                                                            // 86
                                                                                                              // 87
BaseModel.methods = function (methodMap) {                                                                    // 88
  var self = this;                                                                                            // 89
  if (_.isObject(methodMap)) {                                                                                // 90
    _.each(methodMap, function (method, name) {                                                               // 91
      if (_.isFunction(method)) {                                                                             // 92
        if (!self.prototype[name]) {                                                                          // 93
          self.prototype[name] = method;                                                                      // 94
        } else {                                                                                              // 95
          throw new Meteor.Error("existent-method", "The method " + name + " already exists.");               // 96
        }                                                                                                     // 97
      }                                                                                                       // 98
    });                                                                                                       // 99
  }                                                                                                           // 100
};                                                                                                            // 101
                                                                                                              // 102
BaseModel.prototype._getSchema = function () {                                                                // 103
  return this._collection._c2._simpleSchema;                                                                  // 104
};                                                                                                            // 105
                                                                                                              // 106
BaseModel.prototype._checkCollectionExists = function () {                                                    // 107
  if (!this._collection) {                                                                                    // 108
    throw new Error(                                                                                          // 109
      "No collection found. Either use extendAndSetupCollection() or assign a collection to Model.prototype._collection"
    );                                                                                                        // 111
  }                                                                                                           // 112
};                                                                                                            // 113
                                                                                                              // 114
BaseModel.prototype.getCollectionName = function () {                                                         // 115
  this._checkCollectionExists();                                                                              // 116
  return this._collection._name;                                                                              // 117
};                                                                                                            // 118
                                                                                                              // 119
BaseModel.prototype.checkOwnership = function () {                                                            // 120
  return this.userId === Meteor.userId();                                                                     // 121
};                                                                                                            // 122
                                                                                                              // 123
// ===============================================                                                            // 124
// crud/persistence functions                                                                                 // 125
                                                                                                              // 126
BaseModel.prototype.save = function (callback) {                                                              // 127
  this._checkCollectionExists();                                                                              // 128
  var obj = {};                                                                                               // 129
  var schema = this._getSchema();                                                                             // 130
                                                                                                              // 131
  _.each(this, function (value, key) {                                                                        // 132
    if (key !== "_document") {                                                                                // 133
      obj[key] = value;                                                                                       // 134
    }                                                                                                         // 135
  });                                                                                                         // 136
                                                                                                              // 137
                                                                                                              // 138
  if (this._id) {                                                                                             // 139
    obj = diff(obj, this._document);                                                                          // 140
    console.log(obj);                                                                                         // 141
    this._collection.update(this._id, {                                                                       // 142
      $set: obj                                                                                               // 143
    }, callback);                                                                                             // 144
  } else {                                                                                                    // 145
    if (Meteor.isClient && schema) {                                                                          // 146
      obj = schema.clean(obj);                                                                                // 147
    }                                                                                                         // 148
    this._id = this._collection.insert(obj, callback);                                                        // 149
  }                                                                                                           // 150
                                                                                                              // 151
  return this;                                                                                                // 152
};                                                                                                            // 153
                                                                                                              // 154
BaseModel.prototype.update = function (modifier) {                                                            // 155
  if (this._id) {                                                                                             // 156
    this._checkCollectionExists();                                                                            // 157
                                                                                                              // 158
    this._collection.update(this._id, modifier);                                                              // 159
  }                                                                                                           // 160
};                                                                                                            // 161
                                                                                                              // 162
BaseModel.prototype._updateLocal = function (modifier) {                                                      // 163
  this._collection._collection.update(this._id, modifier);                                                    // 164
};                                                                                                            // 165
                                                                                                              // 166
BaseModel.prototype.set = function (key, value) {                                                             // 167
  var obj = {};                                                                                               // 168
  obj[key] = value;                                                                                           // 169
  this[key] = value;                                                                                          // 170
  this._id && this._updateLocal({                                                                             // 171
    $set: obj                                                                                                 // 172
  });                                                                                                         // 173
  return this;                                                                                                // 174
};                                                                                                            // 175
                                                                                                              // 176
BaseModel.prototype.remove = function () {                                                                    // 177
  if (this._id) {                                                                                             // 178
    this._checkCollectionExists();                                                                            // 179
                                                                                                              // 180
    this._collection.remove({                                                                                 // 181
      _id: this._id                                                                                           // 182
    });                                                                                                       // 183
  }                                                                                                           // 184
};                                                                                                            // 185
                                                                                                              // 186
// ===============================================                                                            // 187
// validation functions                                                                                       // 188
                                                                                                              // 189
BaseModel.prototype.clean = function () {                                                                     // 190
  if(this._collection._c2._simpleSchema){                                                                     // 191
    return this._collection._c2._simpleSchema.clean(this._document);                                          // 192
  }                                                                                                           // 193
};                                                                                                            // 194
                                                                                                              // 195
BaseModel.prototype.validate = function (options) {                                                           // 196
  var validator = this.prototype._validator;                                                                  // 197
                                                                                                              // 198
  if (validator) {                                                                                            // 199
    validator.validate(this, options)                                                                         // 200
  } else {                                                                                                    // 201
    throw new Error(                                                                                          // 202
      "Can't validate document when object doesn't have a schema and validation context. Use .appendSchema()" // 203
      );                                                                                                      // 204
  }                                                                                                           // 205
};                                                                                                            // 206
                                                                                                              // 207
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// packages/clinical:base-model/lib/security.js                                                               //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
SimpleSchema.messages({Untrusted: "Inserts/Updates from untrusted code not supported"});                      // 1
                                                                                                              // 2
SimpleSchema.denyUntrusted = function() {                                                                     // 3
    if(this.isSet){                                                                                           // 4
        var autoValue = this.definition.autoValue && this.definition.autoValue.call(this);                    // 5
        var defaultValue = this.definition.defaultValue;                                                      // 6
                                                                                                              // 7
        if(this.value != defaultValue && this.value != autoValue && !this.isFromTrustedCode){                 // 8
            return "Untrusted";                                                                               // 9
        }                                                                                                     // 10
    }                                                                                                         // 11
};                                                                                                            // 12
                                                                                                              // 13
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['clinical:base-model'] = {}, {
  BaseModel: BaseModel
});

})();

//# sourceMappingURL=clinical_base-model.js.map
