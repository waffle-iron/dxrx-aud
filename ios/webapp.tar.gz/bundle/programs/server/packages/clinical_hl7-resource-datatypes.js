(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;

/* Package-scope variables */
var AddressSchema, AnnotationSchema, AttachmentSchema, Code, CodingSchema, CodeableConceptSchema, ContactPointSchema, ConformanceSchema, GroupSchema, HumanNameSchema, IdentifierSchema, PeriodSchema, QuantitySchema, RangeSchema, ReferenceSchema, RatioSchema, SampledDataSchema, SignatureSchema, TimingSchema;

(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/clinical_hl7-resource-datatypes/lib/Address.js                                                  //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
/**
 * @summary Represents an Address
 * @class Address
 * @param {Object} document An object representing an address, ususally a Mongo document.
 * @example

 // Validate an object against the schema
obj = {address: "444 Somewhere St.", zip: "13456"};

isValid = AddressSchema.namedContext("AddressValidator").validate(obj);
// OR
isValid = AddressSchema.namedContext("AddressValidator").validateOne(obj, "keyToValidate");
// OR
isValid = Match.test(obj, AddressSchema);

 patientAddress = new Address({
 use: "home",
 text: "123 Main Street",
 city: "Somewhere",
 state: "Indiana",
 postalCode: "12345"
});
patientAddress.clean();
patientAddress.validate();
patientAddress.save();
 */


// //Address = BaseModel.extendAndSetupCollection('HL7.DataTypes.Addresses');
// Address = BaseModel.extend();
//
//
// //Assign a reference from Meteor.users to User.prototype._collection so BaseModel knows how to access it
// Address.prototype._collection = HL7.DataTypes.Addresses;
//
// // Create a persistent data store for addresses to be stored.
// HL7.DataTypes.Addresses = new Mongo.Collection('HL7.DataTypes.Addresses');
//
// //Add the transform to the collection since Meteor.users is pre-defined by the accounts package
// HL7.DataTypes.Addresses._transform = function (document) {
//   return new Address(document);
// };


// Add  the schema for a collection
AddressSchema = new SimpleSchema({
  "resourceType" : {
    type: String,
    defaultValue: "Address"
    },
  "use" : {
    type: Code
    },
  "type" : {
    type: Code
    },
  "text" : {
    type: String
    },
  "line" : {
    type: [String]
    },
  "city" : {
    type: String
    },
  "district" : {
    type: String
    },
  "state" : {
    type: String
    },
  "postalCode" : {
    type: String
    },
  "country" : {
    type: String
    },
  "period" : {
    type: PeriodSchema
    }
});
// AddressValidator = AddressSchema.namedContext("AddressValidator");
// HL7.DataTypes.Addresses.attachSchema(AddressSchema);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/clinical_hl7-resource-datatypes/lib/Annotation.js                                               //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //


AnnotationSchema = new SimpleSchema({
  "authorReference" : {
    type: ReferenceSchema
    },
  "authorString" : {
    type: String
    },
  "time" : {
    type: Date
    },
  "text" : {
    type: String
    }
});

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/clinical_hl7-resource-datatypes/lib/Attachment.js                                               //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
AttachmentSchema = new SimpleSchema({
  "contentType" : {
    optional: true,
    type: Code
    },
  "language" : {
    optional: true,
    type: Code
    },
  "data" : {
    optional: true,
    type: String // Base64Binary
    },
  "url" : {
    optional: true,
    type: String // Uri
    },
  "size" : {
    optional: true,
    type: String // UnsignedInt
    },
  "hash" : {
    optional: true,
    type: String // Base64Binary
    },
  "title" : {
    optional: true,
    type: String
    },
  "creation" : {
    optional: true,
    type: Date
    }
});

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/clinical_hl7-resource-datatypes/lib/Code.js                                                     //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
Code = new String();
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/clinical_hl7-resource-datatypes/lib/Coding.js                                                   //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //


CodingSchema = new SimpleSchema({
  "system" : {
    type: String
    },
  "code" : {
    type: String
    },
  "version" : {
    optional: true,
    type: String
    },
  "display" : {
    optional: true,
    type: String
    },
  "userSelected" : {
    optional: true,
    type: Boolean
    }
});

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/clinical_hl7-resource-datatypes/lib/CodableConcept.js                                           //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //


CodeableConceptSchema = new SimpleSchema({
  "coding" : {
    type: [ CodingSchema ]
  },
  "text" : {
    type: String
    }
});

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/clinical_hl7-resource-datatypes/lib/ContactPoint.js                                             //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
ContactPointSchema = new SimpleSchema({
  "resourceType" : {
    type: String,
    defaultValue: "ContactPoint",
    },
  "system" : {
    optional: true,
    type: Code
    },
  "value" : {
    optional: true,
    type: String
    },
  "use" : {
    optional: true,
    type: Code
    },
  "rank" : {
    optional: true,
    type: Number // PositiveInt
    },
  "period" : {
    optional: true,
    type: PeriodSchema
    }
});

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/clinical_hl7-resource-datatypes/lib/Conformance.js                                              //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
ConformanceSchema = new SimpleSchema({
  "resourceType" : {
    type: "Conformance",
    // from Resource: id, meta, implicitRules, and language
    // from DomainResource: text, contained, extension, and modifierExtension
  },
  "url" : {
    optional: true,
    type: String  // Logical uri to reference this statement
  },
  "version" : {
    optional: true,
    type: String // Logical id for this version of the statement
  },
  "name" : {
    optional: true,
    type: String // Informal name for this conformance statement
  },
  "status" : {
    optional: true,
    type: Code // draft | active | retired
  },
  "experimental" : {
    optional: true,
    type: Boolean // If for testing purposes, not real usage
  },
  "publisher" : {
    optional: true,
    type: String // Name of the publisher (Organization or individual)
  },
  "contact.$.name" : {
    optional: true,
    type: String // Name of a individual to contact
  },
  // "contact.$.telecom" : {
  //   optional: true,
  //   type: [ ContactPoint ] // Contact details for individual or publisher
  // },
  "date" : {
    optional: true,
    type: Date // R!  Publication Date(/time)
  },
  "description" : {
    optional: true,
    type: String // C? Human description of the conformance statement
  },
  "requirements" : {
    optional: true,
    type: String // Why is this needed?
  },
  "copyright" : {
    optional: true,
    type: String // Use and/or publishing restrictions
  },
  "kind" : {
    optional: true,
    type: Code // R!  instance | capability | requirements
  },
  "software.name" : {
    optional: true,
    type: String // R!  A name the software is known by
  },
  "software.version" : {
    optional: true,
    type: String // Version covered by this statement
  },
  "software.releaseDate" : {
    optional: true,
    type: Date // Date this version released
  },
  "implementation.description" : {
    optional: true,
    type: String // R!  Describes this specific instance
  },
  "implementation.url" : {
    optional: true,
    type: String // Base URL for the installation
  },
  "fhirVersion" : {
    optional: true,
    type: String // R!  FHIR Version the system uses
  },
  "acceptUnknown" : {
    optional: true,
    type: Code // R!  no | extensions | elements | both
  },
  "format" : {
    optional: true,
    type: [Code] // R!  formats supported (xml | json | mime type)
  },
  "profile" : {
    optional: true,
    type: [ ReferenceSchema ] // (StructureDefinition) Profiles for use cases supported
  },
  "rest.$.mode" : {
    optional: true,
    type: Code // R!  client | server
  },
  "rest.$.documentation" : {
    optional: true,
    type: String // General description of implementation
  },
  "rest.$.security.cors" : {
    optional: true,
    type:Boolean // Adds CORS Headers (http://enable-cors.org/)
  },
  "rest.$.security.service" : {
    optional: true,
    type: [ CodeableConceptSchema ] // OAuth | SMART-on-FHIR | NTLM | Basic | Kerberos | Certificates
  },
  "rest.$.security.description" : {
    optional: true,
    type: String // General description of how security works
  },
  "rest.$.security.certificate.$.type" : {
    optional: true,
    type: Code // Mime type for certificate
  },
  //"rest.$.security.certificate.$.blob" : "<base64Binary>" // Actual certificate
  "rest.$.resource.$.type" : {
    optional: true,
    type: Code // R!  A resource type that is supported
  },
  "rest.$.resource.$.profile" : {
    optional: true,
    type:  ReferenceSchema  // (StructureDefinition) Base System profile for all uses of resource
  },
  "rest.$.resource.$.interaction.$.code" : {
    optional: true,
    type: Code // R!  read | vread | update | delete | history-instance | validate | history-type | create | search-type
  },
  "rest.$.resource.$.interaction.$.documentation" : {
    optional: true,
    type: String // Anything special about operation behavior
  },
  "rest.$.resource.$.versioning" : {
    optional: true,
    type: Code // no-version | versioned | versioned-update
  },
  "rest.$.resource.$.readHistory" : {
    optional: true,
    type: Boolean // Whether vRead can return past versions
  },
  "rest.$.resource.$.updateCreate" : {
    optional: true,
    type: Boolean // If update can commit to a new identity
  },
  "rest.$.resource.$.conditionalCreate" : {
    optional: true,
    type: Boolean // If allows/uses conditional create
  },
  "rest.$.resource.$.conditionalUpdate" : {
    optional: true,
    type: Boolean // If allows/uses conditional update
  },
  "rest.$.resource.$.conditionalDelete" : {
    optional: true,
    type: Code // not-supported | single | multiple - how conditional delete is supported
  },
  "rest.$.resource.$.searchInclude" : {
    optional: true,
    type: [String] // _include values supported by the server
  },
  "rest.$.resource.$.searchRevInclude" : {
    optional: true,
    type: [String] // _revinclude values supported by the server
  },
  "rest.$.resource.$.searchParam.$.name" : {
    optional: true,
    type:  String // R!  Name of search parameter
  },
  "rest.$.resource.$.searchParam.$.definition" : {
    optional: true,
    type: String // Source of definition for parameter
  },
  "rest.$.resource.$.searchParam.$.type" : {
    optional: true,
    type: Code // R!  number | date | string | token | reference | composite | quantity | uri
  },
  "rest.$.resource.$.searchParam.$.documentation" : {
    optional: true,
    type: String // Server-specific usage
  },
  "rest.$.resource.$.searchParam.$.target" : {
    optional: true,
    type: [Code] // Types of resource (if a resource reference)
  },
  "rest.$.resource.$.searchParam.$.modifier" : {
    optional: true,
    type: [Code] // missing | exact | contains | not | text | in | not-in | below | above | type
  },
  "rest.$.resource.$.searchParam.$.chain" : {
    optional: true,
    type: [String] // Chained names supported
  },
  "rest.$.code" : {
    optional: true,
    type: Code // R!  transaction | search-system | history-system
  },
  "rest.$.documentation" : {
    optional: true,
    type: String // Anything special about operation behavior
  },
  "rest.transactionMode" : {
    optional: true,
    type: Code // not-supported | batch | transaction | both
  },
  "rest.searchParam" : {
    optional: true,
    blackbox: true,
    type: [ Object ] // Search params for searching all resources
  },
  "rest.operation.$.name" : {
    optional: true,
    type: String // R!  Name by which the operation/query is invoked
  },
  "rest.operation.$.definition" : {
    optional: true,
    type: ReferenceSchema  // (OperationDefinition) R!  The defined operation/query
  },
  "rest.compartment" : {
    optional: true,
    type: [String] // Compartments served/used by system
  },
  "messaging.$.endpoint.$.protocol" : {
    optional: true,
    type: CodingSchema  // R!  http | ftp | mllp +
  },
  "messaging.$.endpoint.$.address" : {
    optional: true,
    type: String // R!  Address of end-point
  //"messaging.$.reliableCache" : "<unsignedInt>" // Reliable Message Cache Length (min)
  },
  "messaging.$.documentation" : {
    optional: true,
    type: String // Messaging interface behavior details
  },
  "messaging.$.event.$.code" : {
    optional: true,
    type: CodingSchema  // R!  Event type
  },
  "messaging.$.event.$.category" : {
    optional: true,
    type: Code // Consequence | Currency | Notification
  },
  "messaging.$.event.$.mode" : {
    optional: true,
    type: Code // R!  sender | receiver
  },
  "messaging.$.event.$.focus" : {
    optional: true,
    type: Code // R!  Resource that's focus of message
  },
  "messaging.$.event.$.request" : {
    optional: true,
    type: ReferenceSchema  // (StructureDefinition) R!  Profile that describes the request
  },
  "messaging.$.event.$.response" : {
    optional: true,
    type: ReferenceSchema  // (StructureDefinition) R!  Profile that describes the response
  },
  "messaging.$.event.$.documentation" : {
    optional: true,
    type:  String // Endpoint-specific event documentation
  },
  "document.$.mode" : {
    optional: true,
    type: Code // R!  producer | consumer
  },
  "document.$.documentation" : {
    optional: true,
    type: String // Description of document support
  },
  "document.$.profile" : {
    optional: true,
    type: ReferenceSchema  // (StructureDefinition) R!  Constraint on a resource used in the document
  }
});

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/clinical_hl7-resource-datatypes/lib/Group.js                                                    //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
GroupSchema = new SimpleSchema({
  "linkId" : {
    optional: true,
    type: String
    },
  "title" : {
    optional: true,
    type: String
    },
  "concept" : {
    optional: true,
    type: [ CodingSchema ]
    },
  "text" : {
    optional: true,
    type: String
    },
  "required" : {
    optional: true,
    type: Boolean
    },
  "repeats" : {
    optional: true,
    type: Boolean
    },
  "group" : {
    optional: true,
    blackbox: true,
    type: GroupSchema
    },
  "question.$.linkId" : {
    optional: true,
    type: String
    },
  "question.$.concept" : {
    optional: true,
    type: [ CodingSchema ]
    },
  "question.$.text" : {
    optional: true,
    type: String
    },
  "question.$.type" : {
    optional: true,
    type: String
    },
  "question.$.required" : {
    optional: true,
    type: Boolean
    },
  "question.$.repeats" : {
    optional: true,
    type: Boolean
    },
  "question.$.options" : {
    optional: true,
    type: ReferenceSchema //(ValueSet)
    },
  "question.$.option" : {
    optional: true,
    type: [ CodingSchema ]
    },
  "question.$.group" : {
    optional: true,
    blackbox: true,
    type: GroupSchema
    },
});

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/clinical_hl7-resource-datatypes/lib/HumanName.js                                                //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
HumanNameSchema = new SimpleSchema({
  "resourceType" : {
    type: String,
    defaultValue: "HumanName"
    },
  "use" : {
    optional: true,
    type: Code
    },
  "text" : {
    optional: true,
    type: String
    },
  "family" : {
    optional: true,
    type: [String]
    },
  "given" : {
    optional: true,
    type: [String]
    },
  "prefix" : {
    optional: true,
    type: [String]
    },
  "suffix" : {
    optional: true,
    type: [String]
    },
  "preferred" : {
    optional: true,
    type: [String]
    },
  "period" : {
    optional: true,
    type: PeriodSchema
    }
});

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/clinical_hl7-resource-datatypes/lib/Identifier.js                                               //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
IdentifierSchema = new SimpleSchema({
  "use" : {
    optional: true,
    type: String
    },
  "type" : {
    optional: true,
    type: CodeableConceptSchema
    },
  "system" : {
    optional: true,
    type: String
    },
  "value" : {
    optional: true,
    type: String
    },
  "period" : {
    optional: true,
    type: PeriodSchema
    },
  "assigner" : {
    optional: true,
    type: ReferenceSchema
    }
});

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/clinical_hl7-resource-datatypes/lib/Period.js                                                   //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
PeriodSchema = new SimpleSchema({
  "start" : {
    type : Date
    },
  "end" : {
    type : Date
    }
});

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/clinical_hl7-resource-datatypes/lib/Quantity.js                                                 //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //


// EXAMPLE
// whenRange: {
//   "low": {
//     "value": 40,
//     "unit": "years",
//     "system": "http://unitsofmeasure.org",
//     "code": "a"
//   },
//   "high": {
//     "value": 90,
//     "unit": "years",
//     "system": "http://unitsofmeasure.org",
//     "code": "a"
//   }
// }

QuantitySchema = new SimpleSchema({
  "value" : {
    type : Number // Decimal
    },
  "comparator": {
    optional: true,
    type: Code
    },
  "unit" : {
    type : String
    },
  "system" : {
    type : String // Uri
    },
  "code" : {
    type : Code
    }
});

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/clinical_hl7-resource-datatypes/lib/Range.js                                                    //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //


RangeSchema = new SimpleSchema({
  "low" : {
    type: QuantitySchema
    },
  "high" : {
    type: QuantitySchema
    }
});

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/clinical_hl7-resource-datatypes/lib/Reference.js                                                //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
ReferenceSchema = new SimpleSchema({
  "reference" : {
    optional: true,
    type: String
    },
  "display" : {
    optional: true,
    type: String
    }
});

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/clinical_hl7-resource-datatypes/lib/Ratio.js                                                    //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
RatioSchema = new SimpleSchema({
  "numerator" : {
    type: QuantitySchema
    },
  "denominator" : {
    type: QuantitySchema
    }
});

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/clinical_hl7-resource-datatypes/lib/SampledData.js                                              //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
SampledDataSchema = new SimpleSchema({
  "origin" : {
    type: QuantitySchema
    },
  "period" : {
    type: Number
    },
  "factor" : {
    type: Number
    },
  "lowerLimit" : {
    type: Number
    },
  "upperLimit" : {
    type: Number
    },
  "dimensions" : {
    type: Number
    },
  "data" : {
    type: String
    }
});

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/clinical_hl7-resource-datatypes/lib/Signature.js                                                //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
SignatureSchema = new SimpleSchema({
  "type" : {
    type: [ CodingSchema ]
    },
  "when" : {
    type: Date
    },
  "whoUri" : {
    type: String
    },
  "whoReference" : {
    type: ReferenceSchema
    },
  "contentType" : {
    type: String
    }
});

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/clinical_hl7-resource-datatypes/lib/Timing.js                                                   //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
TimingSchema = new SimpleSchema({
  "resourceType": {
    type: String,
    defaultValue: "Timing"
  },
  "event": {
    optional: true,
    type: [ Date ]
  },
  "repeat.boundsQuantity": {
    optional: true,
    type: QuantitySchema
  },
  "repeat.boundsRange": {
    optional: true,
    type: RangeSchema
  },
  "repeat.boundsPeriod": {
    optional: true,
    type: PeriodSchema
  },
  "repeat.count": {
    optional: true,
    type: Number
  },
  "repeat.duration": {
    optional: true,
    type: Number
  },
  "repeat.durationMax": {
    optional: true,
    type: Number
  },
  "repeat.durationUnits": {
    optional: true,
    type: Code
  },
  "repeat.frequency": {
    optional: true,
    type: Number
  },
  "repeat.frequencyMax": {
    optional: true,
    type: Number
  },
  "repeat.period": {
    optional: true,
    type: Number
  },
  "repeat.periodMax": {
    optional: true,
    type: Number
  },
  "repeat.periodUnits": {
    optional: true,
    type: Code
  },
  "repeat.when": {
    optional: true,
    type: Code
  }
});

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['clinical:hl7-resource-datatypes'] = {}, {
  AddressSchema: AddressSchema,
  AnnotationSchema: AnnotationSchema,
  AttachmentSchema: AttachmentSchema,
  Code: Code,
  QuantitySchema: QuantitySchema,
  HumanNameSchema: HumanNameSchema,
  ReferenceSchema: ReferenceSchema,
  PeriodSchema: PeriodSchema,
  CodingSchema: CodingSchema,
  CodeableConceptSchema: CodeableConceptSchema,
  IdentifierSchema: IdentifierSchema,
  ContactPointSchema: ContactPointSchema,
  GroupSchema: GroupSchema,
  ConformanceSchema: ConformanceSchema,
  RangeSchema: RangeSchema,
  RatioSchema: RatioSchema,
  SampledDataSchema: SampledDataSchema,
  SignatureSchema: SignatureSchema,
  TimingSchema: TimingSchema
});

})();

//# sourceMappingURL=clinical_hl7-resource-datatypes.js.map
