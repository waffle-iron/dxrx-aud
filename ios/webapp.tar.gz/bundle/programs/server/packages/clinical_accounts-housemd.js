(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var Accounts = Package['accounts-base'].Accounts;
var Practitioners = Package['clinical:hl7-resource-practitioner'].Practitioners;
var PractitionerSchema = Package['clinical:hl7-resource-practitioner'].PractitionerSchema;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var Log = Package.logging.Log;
var Tracker = Package.deps.Tracker;
var Deps = Package.deps.Deps;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var check = Package.check.check;
var Match = Package.check.Match;
var _ = Package.underscore._;
var Random = Package.random.Random;
var EJSON = Package.ejson.EJSON;
var HTML = Package.htmljs.HTML;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                         //
// packages/clinical_accounts-housemd/server/initialize.js                                 //
//                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////
                                                                                           //
// if the database is empty on server start, create some sample data.
// we create a separate bootstrap.users.js file
// because we'll be wanting to set up a number of patient-scenario test users

Meteor.startup(function () {
  if (process.env.INITIALIZE) {
    console.log('Initializing HouseMD users...');
    Meteor.call("initializeUsers");
  }
});



Meteor.methods({
  initializeUsers: function(){
    var userId = null;

    var users = [
      {
        username: 'camron',
        password: 'camron',
        email: 'camron@test.org',
        profile: {
          fullName: 'Alison Camron',
          role: 'Physician',
          avatar: '/packages/clinical_accounts-housemd/housemd/allison.camron.jpg',
          gender: 'Female'
        }
      },
      {
        username: 'foreman',
        password: 'foreman',
        email: 'foreman@test.org',
        profile: {
          fullName: 'Eric Foreman',
          role: 'Physician',
          avatar: '/packages/clinical_accounts-housemd/housemd/eric.foreman.jpg',
          gender: "Male"
        }
      },
      {
        username: 'house',
        password: 'house',
        email: 'house@test.org',
        profile: {
          fullName: 'Gregory House',
          role: 'Physician',
          avatar: '/packages/clinical_accounts-housemd/housemd/gregory.house.jpg',
          gender: "Male"
        }
      },
      {
        username: 'wilson',
        password: 'wilson',
        email: 'wilson@test.org',
        profile: {
          fullName: 'James Wilson',
          role: 'Physician',
          avatar: '/packages/clinical_accounts-housemd/housemd/james.wilson.jpg',
          gender: 'Male'
        }
      },
      {
        username: 'kutner',
        password: 'kutner',
        email: 'kutner@test.org',
        profile: {
          fullName: 'Lawrence Kutner',
          role: 'Physician',
          avatar: '/packages/clinical_accounts-housemd/housemd/lawrence.kutner.jpg',
          gender: 'Male'
        }
      },
      {
        username: 'cuddy',
        password: 'cuddy',
        email: 'cuddy@test.org',
        profile: {
          fullName: 'Lisa Cuddy',
          role: 'Physician',
          avatar: '/packages/clinical_accounts-housemd/housemd/lisa.cuddy.jpg',
          gender: 'Female'
        }
      },
      {
        username: 'chase',
        password: 'chase',
        email: 'chase@test.org',
        profile: {
          fullName: 'Robert Chase',
          role: 'Physician',
          avatar: '/packages/clinical_accounts-housemd/housemd/robert.chase.jpg',
          gender: 'Male'
        }
      },
      {
        username: 'thirteen',
        password: 'thirteen',
        email: 'thirteen@test.org',
        profile: {
          fullName: 'Thirteen',
          role: 'Physician',
          avatar: '/packages/clinical_accounts-housemd/housemd/thirteen.jpg',
          gender: 'Female'
        }
      }
    ];

    if (process.env.Practitioners) {
      if ((Practitioners.find().count() === 0) || (process.env.ADDITIONAL)) {
        users.forEach(function(user){
          var newPractitioner = {
            active: true,
            identifier: [],
            name: {
              text: user.profile.fullName
            },
            gender: user.profile.gender,
            photo: [{
              url: user.profile.avatar
            }]
          };
          newPractitioner.identifier.push({
            use: 'username',
            value: user.username,
            system: Meteor.absoluteUrl(),
            assigner: {
              display: "Autogenerated",
              reference: Meteor.absoluteUrl()
            }
          });

          userId = Practitioners.insert(newPractitioner);
          console.info('Practitioner created: ' + userId);
        });
      } else {
        console.log('Looks like there are already Practitioners initialized.  Skipping.');
      }
    } else {
      // we didn't get specific instructions to save as the HL7 FHIR Practitioner Resource
      // so we're just going to add the HouseMD characters as general users
      if ((Meteor.users.find().count() === 0) || (process.env.ADDITIONAL)) {
        users.forEach(function(user){
          userId = Accounts.createUser(user);
          console.info('User created: ' + userId);
        });
      } else {
        console.log('Looks like there are already Accounts initialized.  Skipping.');
      }

    }
  },
  removeAllUsers: function (){
    Meteor.users.find().forEach(function(user){
      Meteor.users.remove({_id: user._id});
    });
  },
  dropUsers: function (){
    Meteor.users.find().forEach(function(user){
      Meteor.users.remove({_id: user._id});
    });
  }
});

/////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['clinical:accounts-housemd'] = {};

})();

//# sourceMappingURL=clinical_accounts-housemd.js.map
