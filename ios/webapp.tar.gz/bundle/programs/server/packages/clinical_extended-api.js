(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var Log = Package.logging.Log;
var Tracker = Package.deps.Tracker;
var Deps = Package.deps.Deps;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var check = Package.check.check;
var Match = Package.check.Match;
var _ = Package.underscore._;
var Random = Package.random.Random;
var EJSON = Package.ejson.EJSON;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var Style, Collection;

(function(){

/////////////////////////////////////////////////////////////////////////////
//                                                                         //
// packages/clinical_extended-api/packages/clinical_extended-api.js        //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////
                                                                           //
(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/clinical:extended-api/lib/Style.js                       //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
Style = {};                                                          // 1
                                                                     // 2
                                                                     // 3
/**                                                                  // 4
 * @summary Serializes a json object into a text string.             // 5
 * @locus Anywhere                                                   // 6
 * @memberOf Style                                                   // 7
 * @return {String}                                                  // 8
 * @name parse                                                       // 9
 * @example                                                          // 10
 * Template.foo.helpers({                                            // 11
 *   getPageWidth: function(){                                       // 12
 *     return Style.parse({                                          // 13
 *       "width": "80%",                                             // 14
 *       "padding-left": "80%",                                      // 15
 *       "padding-right": "80%"                                      // 16
 *     });                                                           // 17
 *   }                                                               // 18
 * });                                                               // 19
 */                                                                  // 20
                                                                     // 21
                                                                     // 22
Style.parse = function (json) {                                      // 23
  var result = "";                                                   // 24
  $.each(json, function (key, val, index) {                          // 25
    result = result + key + ":" + val;                               // 26
    if (index !== 0) {                                               // 27
      result = result + ";";                                         // 28
    }                                                                // 29
  });                                                                // 30
  return result;                                                     // 31
};                                                                   // 32
                                                                     // 33
///////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/clinical:extended-api/server/collection-extended-api.js  //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
/**                                                                  // 1
 * @summary Toggles a boolean session variable true/false.           // 2
 * @locus Server                                                     // 3
 * @memberOf Mongo.Collection                                        // 4
 * @name drop                                                        // 5
 * @version 1.2.3                                                    // 6
 * @example                                                          // 7
 * ```js                                                             // 8
 *   todos = new Mongo('todos');                                     // 9
 *   todo.insert({name: "Butter"})                                   // 10
 *   todo.insert({name: "Eggs"})                                     // 11
 *   todo.insert({name: "Kale"})                                     // 12
 *   todos.drop();                                                   // 13
 * ```                                                               // 14
 */                                                                  // 15
                                                                     // 16
Mongo.Collection.prototype.drop = function (){                       // 17
  console.log('Mongo.Collection.prototype.drop');                    // 18
  var self = this;                                                   // 19
  self._collection.remove({});                                       // 20
};                                                                   // 21
                                                                     // 22
                                                                     // 23
                                                                     // 24
Mongo.Collection.prototype.onInitialization = function (callback){   // 25
  Mongo.Collection.prototype._initCommand = callback;                // 26
};                                                                   // 27
Mongo.Collection.prototype.init = function (){                       // 28
  return Mongo.Collection.prototype._initCommand();                  // 29
};                                                                   // 30
Mongo.Collection.prototype._initCommand;                             // 31
                                                                     // 32
///////////////////////////////////////////////////////////////////////

}).call(this);

/////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['clinical:extended-api'] = {}, {
  Collection: Collection,
  Style: Style
});

})();

//# sourceMappingURL=clinical_extended-api.js.map
