(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var JsonRoutes = Package['simple:json-routes'].JsonRoutes;
var RestMiddleware = Package['simple:json-routes'].RestMiddleware;
var oAuth2Server = Package['prime8consulting:meteor-oauth2-server'].oAuth2Server;
var Collection = Package['clinical:extended-api'].Collection;
var Style = Package['clinical:extended-api'].Style;
var BaseModel = Package['clinical:base-model'].BaseModel;
var AddressSchema = Package['clinical:hl7-resource-datatypes'].AddressSchema;
var AnnotationSchema = Package['clinical:hl7-resource-datatypes'].AnnotationSchema;
var AttachmentSchema = Package['clinical:hl7-resource-datatypes'].AttachmentSchema;
var Code = Package['clinical:hl7-resource-datatypes'].Code;
var QuantitySchema = Package['clinical:hl7-resource-datatypes'].QuantitySchema;
var HumanNameSchema = Package['clinical:hl7-resource-datatypes'].HumanNameSchema;
var ReferenceSchema = Package['clinical:hl7-resource-datatypes'].ReferenceSchema;
var PeriodSchema = Package['clinical:hl7-resource-datatypes'].PeriodSchema;
var CodingSchema = Package['clinical:hl7-resource-datatypes'].CodingSchema;
var CodeableConceptSchema = Package['clinical:hl7-resource-datatypes'].CodeableConceptSchema;
var IdentifierSchema = Package['clinical:hl7-resource-datatypes'].IdentifierSchema;
var ContactPointSchema = Package['clinical:hl7-resource-datatypes'].ContactPointSchema;
var GroupSchema = Package['clinical:hl7-resource-datatypes'].GroupSchema;
var ConformanceSchema = Package['clinical:hl7-resource-datatypes'].ConformanceSchema;
var RangeSchema = Package['clinical:hl7-resource-datatypes'].RangeSchema;
var RatioSchema = Package['clinical:hl7-resource-datatypes'].RatioSchema;
var SampledDataSchema = Package['clinical:hl7-resource-datatypes'].SampledDataSchema;
var SignatureSchema = Package['clinical:hl7-resource-datatypes'].SignatureSchema;
var TimingSchema = Package['clinical:hl7-resource-datatypes'].TimingSchema;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var Log = Package.logging.Log;
var Tracker = Package.deps.Tracker;
var Deps = Package.deps.Deps;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var check = Package.check.check;
var Match = Package.check.Match;
var _ = Package.underscore._;
var Random = Package.random.Random;
var EJSON = Package.ejson.EJSON;
var Collection2 = Package['aldeed:collection2-core'].Collection2;
var CollectionHooks = Package['matb33:collection-hooks'].CollectionHooks;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var Patient, Patients, PatientSchema;

(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// packages/clinical_hl7-resource-patient/lib/Patients.js                                                //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //

/**
 * @summary Represents a Patient; typically documented by a clinician.  A Clinical Impression can be self-assigned, in which case it may be considered a Status or ReportedCondition.
 * @class Patient
 * @param {Object} document An object representing an impression, ususally a Mongo document.
 * @example
newPatient = new Patient({
  name: {
    given: "Jane",
    family: "Doe"
  },
  gender: "female",
  identifier: "12345"
});


newPatient.clean();
newPatient.validate();
newPatient.save();
 */


// create the object using our BaseModel
Patient = BaseModel.extend();


//Assign a collection so the object knows how to perform CRUD operations
Patient.prototype._collection = Patients;

// Create a persistent data store for addresses to be stored.
// HL7.Resources.Patients = new Mongo.Collection('HL7.Resources.Patients');
Patients = new Mongo.Collection('Patients');
Patients.allow({
  insert: function () {
    return true;
  },
  update: function () {
    return true;
  },
  remove: function () {
    return true;
  }
});

//Add the transform to the collection since Meteor.users is pre-defined by the accounts package
Patients._transform = function (document) {
  return new Patient(document);
};


if (Meteor.isClient){
  Meteor.subscribe("Patients");
}

if (Meteor.isServer){
  Meteor.publish("Patients", function (argument){
    return Patients.find();
  });
}


PatientSchema = new SimpleSchema({
  "resourceType" : {
    type: String,
    defaultValue: "Patient"
  },
  "identifier" : {
    optional: true,
    type: [ IdentifierSchema ]
    },
  "active" : {
    type: Boolean,
    defaultValue: true
    },
  "name" : {
    type: [ HumanNameSchema ]
    },
  "telecom" : {
    optional: true,
    type: [ ContactPointSchema ]
    },
  "gender" : {
    optional: true,
    type: String
    },
  "birthDate" : {
    optional: true,
    type: Date
    },
  "deceasedBoolean" : {
    optional: true,
    type: Boolean
    },
  "deceasedDateTime" : {
    optional: true,
    type: Date
    },
  "address" : {
    optional: true,
    type: [ String ]
    },
  "maritalStatus" : {
    optional: true,
    type: CodeableConceptSchema
    },
  "multipleBirthBoolean" : {
    optional: true,
    type: Boolean
    },
  "multipleBirthInteger" : {
    optional: true,
    type: Number
    },
  "photo" : {
    optional: true,
    type: [ AttachmentSchema ]
    },
  "contact.$.relationship" : {
    optional: true,
    type: [ String ]
    },
  "contact.$.name" : {
    optional: true,
    type: HumanNameSchema
    },
  "contact.$.telecom" : {
    optional: true,
    type: [ ContactPointSchema ]
    },
  "contact.$.address" : {
    optional: true,
    type: AddressSchema
    },
  "contact.$.gender" : {
    optional: true,
    type: String
    },
  "contact.$.organization" : {
    optional: true,
    type: String
    },
  "contact.$.period" : {
    optional: true,
    type: PeriodSchema
    },
  "animal.species" : {
    optional: true,
    type: String
    //type: CodeableConceptSchema
    },
  "animal.breed" : {
    optional: true,
    type: CodeableConceptSchema
    },
  "animal.genderStatus" : {
    optional: true,
    type: CodeableConceptSchema
    },
  "communication.$.language" : {
    optional: true,
    type: CodeableConceptSchema
    },
  "communication.$.preferred" : {
    optional: true,
    type: Boolean
    },
  "careProvider" : {
    optional: true,
    type: [ ReferenceSchema ]
    },
  "managingOrganization" : {
    optional: true,
    type: String
    },
  "link.$.other" : {
    optional: true,
    type: String
    },
  "link.$.type" : {
    optional: true,
    type: String
    }
});
Patients.attachSchema(PatientSchema);

//================================================================





/**
 * @summary The displayed name of the patient.
 * @memberOf Patient
 * @name displayName
 * @version 1.2.3
 * @returns {Boolean}
 * @example
 * ```js
 * ```
 */

Patient.prototype.displayName = function () {

};

///////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// packages/clinical_hl7-resource-patient/server/rest.js                                                 //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
JsonRoutes.Middleware.use(
  '/api/*',
  oAuth2Server.oauthserver.authorise()   // OAUTH FLOW - A7.1
);


JsonRoutes.add("get", "/open/Patient/:id", function (req, res, next) {
  if (process.env.OPEN) {
    console.log('GET /PublicPatient/' + req.params.id);
    //console.log('res', res);

    var id = req.params.id;
    console.log('Patients.findOne(id)', Patients.findOne(id));

    if (typeof SiteStatistics === "object") {
      SiteStatistics.update({_id: "configuration"}, {$inc:{
        "Patients.count.read": 1
      }});
    }

    // because we're using BaseModel and a _transform() function
    // Patients returns an object instead of a pure JSON document
    // it stores a shadow reference of the original doc, which we're removing here
    var patientData = Patients.findOne(id);
    delete patientData._document;

    JsonRoutes.sendResult(res, {
      code: 200,
      data: patientData
    });

  } else {
    JsonRoutes.sendResult(res, {
      code: 401
    });
  }
});

JsonRoutes.add("get", "/open/Patient", function (req, res, next) {
  if (process.env.OPEN) {
    console.log('GET /PublicPatient', req.query);
    //console.log('res', res);

    if (typeof SiteStatistics === "object") {
      SiteStatistics.update({_id: "configuration"}, {$inc:{
        "Patients.count.search-type": 1
      }});
    }

    var databaseQuery = {};

    if (req.query.family) {
      databaseQuery['name'] = {
        $elemMatch: {
          'family': req.query.family
        }
      };
    }
    if (req.query.given) {
      databaseQuery['name.given'] = {
        $elemMatch: {
          'given': req.query.given
        }
      };
    }
    if (req.query.name) {
      databaseQuery['name.text'] = {
        $elemMatch: {
          'text': req.query.name
        }
      };
    }
    if (req.query.identifier) {
      databaseQuery['_id'] = req.query.identifier;
    }
    if (req.query.gender) {
      databaseQuery['gender'] = req.query.gender;
    }
    if (req.query.birthdate) {
      databaseQuery['birthDate'] = req.query.birthdate;
    }

    console.log('databaseQuery', databaseQuery);

    // var id = req.params.id;
    console.log('Patients.findOne(id)', Patients.find(databaseQuery).fetch());

    // because we're using BaseModel and a _transform() function
    // Patients returns an object instead of a pure JSON document
    // it stores a shadow reference of the original doc, which we're removing here
    var patientData = Patients.find(databaseQuery).fetch();
    delete patientData._document;

    JsonRoutes.sendResult(res, {
      code: 200,
      data: patientData
    });
  } else {
    JsonRoutes.sendResult(res, {
      code: 401
    });
  }
});


JsonRoutes.add("get", "/fhir/Patients/:id", function (req, res, next) {
  process.env.DEBUG && console.log('GET /fhir/Patient/' + req.params.id);

  res.setHeader("Access-Control-Allow-Origin", "*");

  var accessTokenStr = (req.params && req.params.access_token) || (req.query && req.query.access_token);
  var accessToken = oAuth2Server.collections.accessToken.findOne({accessToken: accessTokenStr});

  if (accessToken || process.env.NOAUTH) {
    process.env.TRACE && console.log('accessToken', accessToken);
    process.env.TRACE && console.log('accessToken.userId', accessToken.userId);

    if (typeof SiteStatistics === "object") {
      SiteStatistics.update({_id: "configuration"}, {$inc:{
        "Patients.count.read": 1
      }});
    }

    var id = req.params.id;
    var patientData = Patients.findOne(id);
    delete patientData._document;
    process.env.TRACE && console.log('patientData', patientData);

    JsonRoutes.sendResult(res, {
      code: 200,
      data: patientData
    });
  } else {
    JsonRoutes.sendResult(res, {
      code: 401
    });
  }
});



JsonRoutes.add("get", "/fhir/Patient", function (req, res, next) {
  process.env.DEBUG && console.log('GET /fhir/Patient', req.query);
  // console.log('GET /fhir/Patient', req.query);
  // console.log('process.env.DEBUG', process.env.DEBUG);

  res.setHeader("Access-Control-Allow-Origin", "*");

  var accessTokenStr = (req.params && req.params.access_token) || (req.query && req.query.access_token);
  var accessToken = oAuth2Server.collections.accessToken.findOne({accessToken: accessTokenStr});

  if (accessToken || process.env.NOAUTH) {
    process.env.TRACE && console.log('accessToken', accessToken);
    process.env.TRACE && console.log('accessToken.userId', accessToken.userId);

    if (typeof SiteStatistics === "object") {
      SiteStatistics.update({_id: "configuration"}, {$inc:{
        "Patients.count.search-type": 1
      }});
    }

    var databaseQuery = {};

    if (req.query.family) {
      databaseQuery['name'] = {
        $elemMatch: {
          'family': req.query.family
        }
      };
    }
    if (req.query.given) {
      databaseQuery['name'] = {
        $elemMatch: {
          'given': req.query.given
        }
      };
    }
    if (req.query.name) {
      databaseQuery['name'] = {
        $elemMatch: {
          'text': req.query.text
        }
      };
    }
    if (req.query.identifier) {
      databaseQuery['_id'] = req.query.identifier;
    }
    if (req.query.gender) {
      databaseQuery['gender'] = req.query.gender;
    }
    if (req.query.birthdate) {
      databaseQuery['birthDate'] = req.query.birthdate;
    }

    process.env.DEBUG && console.log('databaseQuery', databaseQuery);
    process.env.DEBUG && console.log('Patients.find(id)', Patients.find(databaseQuery).fetch());

    // because we're using BaseModel and a _transform() function
    // Patients returns an object instead of a pure JSON document
    // it stores a shadow reference of the original doc, which we're removing here
    var patientData = Patients.find(databaseQuery).fetch();

    patientData.forEach(function(patient){
      delete patient._document;
    });

    JsonRoutes.sendResult(res, {
      code: 200,
      data: patientData
    });
  } else {
    JsonRoutes.sendResult(res, {
      code: 401
    });
  }
});

// WebApp.connectHandlers.use("/fhir/Patient", function(req, res, next) {
//   res.setHeader("Access-Control-Allow-Origin", "*");
//   return next();
// });

///////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['clinical:hl7-resource-patient'] = {}, {
  Patient: Patient,
  Patients: Patients,
  PatientSchema: PatientSchema
});

})();

//# sourceMappingURL=clinical_hl7-resource-patient.js.map
